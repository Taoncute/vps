const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const net = require('net');

// --- CẤU HÌNH ---
// Token và Chat ID của bạn đã được cập nhật trực tiếp
const TOKEN = '8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q';
const CHAT_ID = '7803422532';

// Tên file chứa danh sách RDP (mặc định là good.txt)
const RDP_FILE = 'good.txt';

// Cổng RDP mặc định nếu không được chỉ định trong file
const DEFAULT_RDP_PORT = 3389;

// Khởi tạo bot
const bot = new TelegramBot(TOKEN);

/**
 * Kiểm tra xem cổng RDP có đang mở hay không.
 */
function checkRdpPort(host, port) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        const timeout = 5000; // 5 giây timeout

        socket.setTimeout(timeout);

        socket.on('connect', () => {
            socket.destroy();
            resolve({ success: true, status: `Online ✅ (Port ${port})` });
        });

        socket.on('timeout', () => {
            socket.destroy();
            resolve({ success: false, status: `Offline ❌ (Timeout - Port ${port})` });
        });

        socket.on('error', (err) => {
            socket.destroy();
            resolve({ success: false, status: `Offline ❌ (Lỗi: ${err.message})` });
        });

        socket.connect(port, host);
    });
}

/**
 * Phân tích dòng RDP theo định dạng: IP:Port@User\Pass;...
 */
function parseRdpLine(line) {
    // Loại bỏ khoảng trắng và dấu chấm phẩy ở cuối
    line = line.trim().replace(/;$/, '');
    
    let addressPart;
    if (line.includes('@')) {
        addressPart = line.split('@')[0];
    } else {
        addressPart = line.includes(';') ? line.split(';')[0] : line;
    }

    let host, port;
    if (addressPart.includes(':')) {
        const parts = addressPart.split(':');
        host = parts[0];
        port = parseInt(parts[1], 10) || DEFAULT_RDP_PORT;
    } else {
        host = addressPart;
        port = DEFAULT_RDP_PORT;
    }
        
    return { host, port };
}

/**
 * Đọc file, kiểm tra danh sách RDP và gửi thông báo về Telegram.
 */
async function checkAndNotify() {
    if (!fs.existsSync(RDP_FILE)) {
        console.error(`Lỗi: Không tìm thấy file ${RDP_FILE}. Vui lòng tạo file này trước.`);
        return;
    }

    // Đọc danh sách RDP từ file
    const content = fs.readFileSync(RDP_FILE, 'utf-8');
    const lines = content.split('\n').map(line => line.trim()).filter(line => line.length > 0);

    if (lines.length === 0) {
        console.log("Danh sách RDP trống.");
        return;
    }

    console.log(`Đang kiểm tra ${lines.length} RDP từ file ${RDP_FILE}...`);
    
    const results = [];
    for (const line of lines) {
        const { host, port } = parseRdpLine(line);
        const { status } = await checkRdpPort(host, port);
        
        // Hiển thị dòng gốc thu gọn để dễ nhìn
        const displayName = line.includes('@') ? line.split('@')[0] : line.substring(0, 30);
        results.push(`🖥️ \`${displayName}\`: ${status}`);
    }
    
    // Chuẩn bị nội dung tin nhắn
    const header = `📊 **Báo cáo trạng thái RDP (${lines.length} máy):**\n\n`;
    let currentMsg = header;
    
    for (const res of results) {
        // Telegram giới hạn 4096 ký tự mỗi tin nhắn
        if (currentMsg.length + res.length + 2 > 4000) {
            await bot.sendMessage(CHAT_ID, currentMsg, { parse_mode: 'Markdown' });
            currentMsg = header + res + "\n";
        } else {
            currentMsg += res + "\n";
        }
    }
            
    try {
        await bot.sendMessage(CHAT_ID, currentMsg, { parse_mode: 'Markdown' });
        console.log("Đã gửi thông báo về Telegram thành công!");
    } catch (error) {
        console.error(`Lỗi khi gửi tin nhắn Telegram: ${error.message}`);
        console.log("\nLƯU Ý: Hãy đảm bảo bạn đã nhắn tin /start cho bot trước.");
    }
}

// Chạy chương trình
checkAndNotify();
