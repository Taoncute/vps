# Hướng dẫn sử dụng Telegram RDP Check Bot (Phiên bản Node.js)

Chào bạn,

Đây là phiên bản Telegram Bot được viết bằng Node.js, có chức năng kiểm tra trạng thái hoạt động của các máy chủ RDP (Remote Desktop Protocol) và gửi thông báo về Telegram của bạn. Phiên bản này được thiết kế để xử lý các tệp danh sách RDP có định dạng phức tạp như `IP:Port@User\Pass;`.

## 1. Giới thiệu về Bot

Bot Telegram này giúp bạn tự động kiểm tra trạng thái hoạt động (Online/Offline) của các máy chủ RDP. Bot sẽ đọc danh sách từ tệp tin `good.txt` bạn cung cấp, phân tích địa chỉ IP và cổng (nếu có), sau đó kiểm tra kết nối đến cổng RDP của từng máy và gửi báo cáo chi tiết đến tài khoản Telegram của bạn.

## 2. Chuẩn bị

Để bot có thể hoạt động, bạn cần có:

1.  **Node.js**: Đảm bảo bạn đã cài đặt Node.js trên máy chủ hoặc máy tính mà bạn muốn chạy bot. Bạn có thể tải xuống từ trang web chính thức: [nodejs.org](https://nodejs.org/en/download/).
2.  **Telegram Bot Token và Chat ID**: Mình đã tích hợp sẵn Token (`8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q`) và Chat ID (`7803422532`) của bạn vào mã nguồn. Bạn không cần phải cấu hình lại.

## 3. Cài đặt môi trường

1.  **Tạo thư mục dự án**: Tạo một thư mục mới cho dự án của bạn, ví dụ: `rdp_bot_node`.
2.  **Di chuyển vào thư mục**: Mở Terminal hoặc Command Prompt và điều hướng đến thư mục bạn vừa tạo.
    ```bash
    cd rdp_bot_node
    ```
3.  **Cài đặt thư viện `node-telegram-bot-api`**: Chạy lệnh sau để cài đặt thư viện cần thiết:
    ```bash
    pnpm add node-telegram-bot-api
    # Hoặc dùng npm:
    # npm install node-telegram-bot-api
    ```

## 4. Mã nguồn Bot

Dưới đây là mã nguồn của bot. Bạn cần lưu mã này vào một tệp có tên `index.js` trong thư mục dự án của bạn.

```javascript
const TelegramBot = require(\'node-telegram-bot-api\');
const fs = require(\'fs\');
const net = require(\'net\');

// --- CẤU HÌNH ---
// Token và Chat ID của bạn đã được cập nhật trực tiếp
const TOKEN = \'8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q\';
const CHAT_ID = \'7803422532\';

// Tên file chứa danh sách RDP (mặc định là good.txt)
const RDP_FILE = \'good.txt\';

// Cổng RDP mặc định nếu không được chỉ định trong file
const DEFAULT_RDP_PORT = 3389;

// Khởi tạo bot
const bot = new TelegramBot(TOKEN);

/**
 * Kiểm tra xem cổng RDP có đang mở hay không.
 */
function checkRdpPort(host, port) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        const timeout = 5000; // 5 giây timeout

        socket.setTimeout(timeout);

        socket.on(\'connect\', () => {
            socket.destroy();
            resolve({ success: true, status: `Online ✅ (Port ${port})` });
        });

        socket.on(\'timeout\', () => {
            socket.destroy();
            resolve({ success: false, status: `Offline ❌ (Timeout - Port ${port})` });
        });

        socket.on(\'error\', (err) => {
            socket.destroy();
            resolve({ success: false, status: `Offline ❌ (Lỗi: ${err.message})` });
        });

        socket.connect(port, host);
    });
}

/**
 * Phân tích dòng RDP theo định dạng: IP:Port@User\\Pass;...
 */
function parseRdpLine(line) {
    // Loại bỏ khoảng trắng và dấu chấm phẩy ở cuối
    line = line.trim().replace(/;$/, \'\');
    
    let addressPart;
    if (line.includes(\'@\')) {
        addressPart = line.split(\'@\')[0];
    } else {
        addressPart = line.includes(\'\;') ? line.split(\'\;\')[0] : line;
    }

    let host, port;
    if (addressPart.includes(\':\')) {
        const parts = addressPart.split(\':\');
        host = parts[0];
        port = parseInt(parts[1], 10) || DEFAULT_RDP_PORT;
    } else {
        host = addressPart;
        port = DEFAULT_RDP_PORT;
    }
        
    return { host, port };
}

/**
 * Đọc file, kiểm tra danh sách RDP và gửi thông báo về Telegram.
 */
async function checkAndNotify() {
    if (!fs.existsSync(RDP_FILE)) {
        console.error(`Lỗi: Không tìm thấy file ${RDP_FILE}. Vui lòng tạo file này trước.`);
        return;
    }

    // Đọc danh sách RDP từ file
    const content = fs.readFileSync(RDP_FILE, \'utf-8\');
    const lines = content.split(\'\\n\').map(line => line.trim()).filter(line => line.length > 0);

    if (lines.length === 0) {
        console.log("Danh sách RDP trống.");
        return;
    }

    console.log(`Đang kiểm tra ${lines.length} RDP từ file ${RDP_FILE}...`);
    
    const results = [];
    for (const line of lines) {
        const { host, port } = parseRdpLine(line);
        const { status } = await checkRdpPort(host, port);
        
        // Hiển thị dòng gốc thu gọn để dễ nhìn
        const displayName = line.includes(\'@\') ? line.split(\'@\')[0] : line.substring(0, 30);
        results.push(`🖥️ \`${displayName}\`: ${status}`);
    }
    
    // Chuẩn bị nội dung tin nhắn
    const header = `📊 **Báo cáo trạng thái RDP (${lines.length} máy):**\\n\\n`;
    let currentMsg = header;
    
    for (const res of results) {
        // Telegram giới hạn 4096 ký tự mỗi tin nhắn
        if (currentMsg.length + res.length + 2 > 4000) {
            await bot.sendMessage(CHAT_ID, currentMsg, { parse_mode: \'Markdown\' });
            currentMsg = header + res + "\\n";
        } else {
            currentMsg += res + "\\n";
        }
    }
            
    try {
        await bot.sendMessage(CHAT_ID, currentMsg, { parse_mode: \'Markdown\' });
        console.log("Đã gửi thông báo về Telegram thành công!");
    } catch (error) {
        console.error(`Lỗi khi gửi tin nhắn Telegram: ${error.message}`);
        console.log("\\nLƯU Ý: Hãy đảm bảo bạn đã nhắn tin /start cho bot trước.");
    }
}

// Chạy chương trình
checkAndNotify();
```

## 5. Tạo tệp danh sách RDP (`good.txt`)

Bạn cần tạo một tệp văn bản có tên `good.txt` trong cùng thư mục với tệp `index.js`. Mỗi dòng trong tệp này sẽ chứa thông tin RDP theo định dạng bạn đã cung cấp:

`IP:Port@User\Pass;`

Bot sẽ tự động phân tích để lấy ra IP và Port để kiểm tra. Nếu Port không được chỉ định, bot sẽ mặc định sử dụng cổng `3389`.

**Ví dụ về nội dung tệp `good.txt`:**
```
122.176.135.197:3389@WIN-3NRLH5MC9LN\administrator;
117.206.117.82:3389@HALIMA\user;
43.230.64.234:3389@WIN-90Q6KIQ0CQS\test;
49.249.29.6:3389@USER\user;123
103.116.84.222:3389@DESKTOP-CBDMQPU\tally;123
```

## 6. Cách chạy Bot

Sau khi đã lưu mã nguồn `index.js` và tạo tệp `good.txt` trong cùng thư mục, bạn có thể chạy bot bằng cách mở Terminal hoặc Command Prompt, điều hướng đến thư mục dự án và chạy lệnh sau:

```bash
node index.js
```

Bot sẽ thực hiện kiểm tra và gửi một tin nhắn báo cáo về Telegram của bạn.

## 7. Tự động hóa việc kiểm tra (Tùy chọn)

Để bot tự động kiểm tra định kỳ, bạn có thể sử dụng các công cụ lập lịch tác vụ của hệ điều hành:

*   **Trên Linux/macOS (Cron Job)**:
    Mở terminal và gõ `crontab -e`. Thêm dòng sau vào cuối tệp (ví dụ, để chạy mỗi 30 phút):
    ```cron
    */30 * * * * /usr/bin/node /duong/dan/den/rdp_bot_node/index.js
    ```
    *Hãy thay `/usr/bin/node` bằng đường dẫn đến trình thông dịch Node.js của bạn và `/duong/dan/den/rdp_bot_node/index.js` bằng đường dẫn tuyệt đối đến tệp script của bạn.*

*   **Trên Windows (Task Scheduler)**:
    Bạn có thể thiết lập một tác vụ mới trong Task Scheduler để chạy tệp `index.js` theo lịch trình mong muốn.

**Lưu ý quan trọng**: Hãy đảm bảo bạn đã nhấn nút **Bắt đầu (Start)** trên bot của mình trước khi chạy code để bot có quyền gửi tin nhắn cho bạn nhé!

Chúc bạn thành công! Nếu có bất kỳ câu hỏi nào, đừng ngần ngại hỏi nhé.
