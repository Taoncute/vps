/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: { '2xl': '1400px' },
    },
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        // Game Shop custom colors
        neon: {
          cyan: '#00F5FF',
          purple: '#BF00FF',
          gold: '#FFD700',
          green: '#00FF88',
        },
        dark: {
          900: '#050508',
          800: '#0A0A12',
          700: '#0F0F1E',
          600: '#151528',
          500: '#1E1E35',
          400: '#252540',
        },
      },
      backgroundImage: {
        'gradient-gaming': 'linear-gradient(135deg, #050508 0%, #0A0A12 50%, #0F0F1E 100%)',
        'gradient-neon': 'linear-gradient(135deg, #BF00FF 0%, #00F5FF 100%)',
        'gradient-gold': 'linear-gradient(135deg, #FFD700 0%, #FF8C00 100%)',
        'gradient-roblox': 'linear-gradient(135deg, #E13125 0%, #FF6B35 100%)',
        'gradient-genshin': 'linear-gradient(135deg, #4158D0 0%, #C850C0 50%, #FFCC70 100%)',
      },
      fontFamily: {
        display: ['Orbitron', 'sans-serif'],
        body: ['Rajdhani', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
        'glow-pulse': 'glow-pulse 2s ease-in-out infinite',
        'slide-in': 'slide-in 0.5s ease-out',
        'fade-up': 'fade-up 0.6s ease-out',
        'shimmer': 'shimmer 2s infinite',
        'spin-slow': 'spin 8s linear infinite',
        'scan': 'scan 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'glow-pulse': {
          '0%, 100%': { boxShadow: '0 0 5px #00F5FF, 0 0 20px #00F5FF44' },
          '50%': { boxShadow: '0 0 20px #00F5FF, 0 0 60px #00F5FF66, 0 0 100px #00F5FF22' },
        },
        'slide-in': {
          '0%': { opacity: '0', transform: 'translateX(-20px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        scan: {
          '0%, 100%': { top: '0%' },
          '50%': { top: '100%' },
        },
      },
      boxShadow: {
        neon: '0 0 10px #00F5FF, 0 0 40px #00F5FF44',
        'neon-purple': '0 0 10px #BF00FF, 0 0 40px #BF00FF44',
        'neon-gold': '0 0 10px #FFD700, 0 0 40px #FFD70044',
        card: '0 4px 30px rgba(0,0,0,0.5)',
        'card-hover': '0 8px 40px rgba(0,245,255,0.15)',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}
