// prisma/seed.ts
import { PrismaClient, GameType, Role } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Admin user
  const hashedPassword = await bcrypt.hash('Admin@123456', 12)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@gameshop.vn' },
    update: {},
    create: {
      username: 'admin',
      email: 'admin@gameshop.vn',
      password: hashedPassword,
      role: Role.ADMIN,
      balance: 0,
    },
  })
  console.log('✅ Admin created:', admin.email)

  // Settings
  const settings = [
    { key: 'SITE_NAME', value: 'GameShop VN' },
    { key: 'SITE_TAGLINE', value: 'Shop Game Uy Tín #1 Việt Nam' },
    { key: 'CARD_FEE_PERCENT', value: '20' },
    { key: 'BANK_ACCOUNT', value: '22523112009' },
    { key: 'BANK_NAME', value: 'TPBank' },
    { key: 'BANK_OWNER', value: 'DUONG VINH MANH' },
    { key: 'CARD_API_KEY', value: 'your_thesieure_api_key' },
    { key: 'CARD_API_SECRET', value: 'your_thesieure_secret' },
    { key: 'TELEGRAM_BOT_TOKEN', value: 'your_telegram_bot_token' },
    { key: 'TELEGRAM_ADMIN_ID', value: '7803422532' },
    { key: 'PROMO_CODE', value: 'HE2026' },
    { key: 'PROMO_PERCENT', value: '10' },
    { key: 'MIN_RECHARGE_BANK', value: '10000' },
  ]
  for (const s of settings) {
    await prisma.setting.upsert({ where: { key: s.key }, update: { value: s.value }, create: s })
  }
  console.log('✅ Settings seeded')

  // Banners
  await prisma.banner.createMany({
    data: [
      { title: 'ROBLOX BLOX FRUITS', subtitle: 'Tài khoản cấp cao - Giá tốt nhất thị trường', isActive: true, order: 1 },
      { title: 'GENSHIN IMPACT', subtitle: 'Acc 5 sao - Nạp Genesis Crystals giá rẻ', isActive: true, order: 2 },
      { title: 'KHUYẾN MÃI HE2026', subtitle: 'Nhập mã HE2026 - Giảm 10% mọi đơn hàng', isActive: true, order: 3 },
    ],
    skipDuplicates: true,
  })
  console.log('✅ Banners seeded')

  // Announcements
  await prisma.announcement.createMany({
    data: [
      { content: '🎉 Nhập mã HE2026 để nhận giảm giá 10% cho đơn hàng đầu tiên!', type: 'success', isActive: true },
      { content: '⚡ Giao dịch tự động 24/7 - Nhận hàng ngay sau khi thanh toán', type: 'info', isActive: true },
    ],
    skipDuplicates: true,
  })

  // Roblox Products
  const robloxProducts = [
    {
      name: 'Acc Blox Fruits Level 2450 Max',
      description: 'Account Blox Fruits full level 2450, có tộc V4, CDK đầy đủ, full boss',
      price: 150000,
      originalPrice: 200000,
      game: GameType.ROBLOX,
      category: 'account',
      stock: 15,
      isFeatured: true,
      metadata: { level: 2450, race: 'V4', hasCDK: true, server: 'First Sea/Second Sea/Third Sea' },
    },
    {
      name: 'Acc Blox Fruits Level 1800+',
      description: 'Account đã qua Third Sea, nhiều DF tốt, tộc V3',
      price: 80000,
      originalPrice: 120000,
      game: GameType.ROBLOX,
      category: 'account',
      stock: 30,
      metadata: { level: 1800, race: 'V3', hasCDK: false },
    },
    {
      name: 'Robux 800 (120 Giờ)',
      description: 'Nạp 800 Robux vào tài khoản của bạn, bảo hành 120 giờ',
      price: 55000,
      game: GameType.ROBLOX,
      category: 'robux',
      stock: 999,
      isFeatured: true,
      metadata: { robuxAmount: 800 },
    },
    {
      name: 'Robux 1700 (120 Giờ)',
      description: 'Nạp 1700 Robux - giá trị cao nhất',
      price: 110000,
      game: GameType.ROBLOX,
      category: 'robux',
      stock: 999,
      metadata: { robuxAmount: 1700 },
    },
    {
      name: 'Cày Thuê Blox Fruits - Lên Max Level',
      description: 'Dịch vụ cày level từ 1 đến 2450 trong 3-5 ngày',
      price: 200000,
      game: GameType.ROBLOX,
      category: 'service',
      stock: 10,
      metadata: { duration: '3-5 ngày', type: 'farming' },
    },
    {
      name: 'Gacha Nhân Phẩm - 10 Lần',
      description: 'Dịch vụ gacha Blox Fruits, bảo hành nhận được ít nhất 1 DF hiếm',
      price: 50000,
      game: GameType.ROBLOX,
      category: 'service',
      stock: 50,
      metadata: { rolls: 10 },
    },
  ]

  for (const p of robloxProducts) {
    await prisma.product.create({ data: p })
  }
  console.log('✅ Roblox products seeded')

  // Genshin Products
  const genshinProducts = [
    {
      name: 'Acc Genshin AR55 - 5 Nhân Vật 5 Sao',
      description: 'Account AR55, có Hu Tao, Raiden, Ganyu, Kazuha, Yelan. Weapon đủ set. Server Asia.',
      price: 500000,
      originalPrice: 700000,
      game: GameType.GENSHIN,
      category: 'account',
      stock: 5,
      isFeatured: true,
      metadata: {
        ar: 55,
        server: 'Asia',
        characters: ['Hu Tao', 'Raiden Shogun', 'Ganyu', 'Kazuha', 'Yelan'],
        abyss: '12*',
      },
    },
    {
      name: 'Acc Reroll AR20 - Nahida + Furina',
      description: 'Tài khoản reroll fresh, có sẵn Nahida và Furina C0',
      price: 120000,
      originalPrice: 180000,
      game: GameType.GENSHIN,
      category: 'account',
      stock: 20,
      metadata: { ar: 20, server: 'Asia', characters: ['Nahida', 'Furina'], type: 'reroll' },
    },
    {
      name: 'Nạp 6480 Genesis Crystals',
      description: 'Nạp trực tiếp 6480 Genesis Crystals vào UID của bạn',
      price: 1580000,
      game: GameType.GENSHIN,
      category: 'crystal',
      stock: 999,
      isFeatured: true,
      metadata: { crystals: 6480, bonus: 'Primogems included' },
    },
    {
      name: 'Nạp 980 Genesis Crystals',
      description: 'Gói nạp nhỏ 980 Genesis Crystals',
      price: 250000,
      game: GameType.GENSHIN,
      category: 'crystal',
      stock: 999,
      metadata: { crystals: 980 },
    },
    {
      name: 'Cày Thuê La Hoàn Sâu Thẳm 36*',
      description: 'Dịch vụ cày La Hoàn đạt 36* trong 1 chu kỳ, bảo đảm kết quả',
      price: 150000,
      game: GameType.GENSHIN,
      category: 'service',
      stock: 20,
      metadata: { stars: 36, duration: '3-7 ngày', type: 'abyss' },
    },
    {
      name: 'Cày Thuê Thám Hiểm Bản Đồ 100%',
      description: 'Hoàn thành thám hiểm tất cả vùng đất, thu thập toàn bộ Oculus và Waypoints',
      price: 200000,
      game: GameType.GENSHIN,
      category: 'service',
      stock: 15,
      metadata: { type: 'exploration', completion: '100%' },
    },
  ]

  for (const p of genshinProducts) {
    await prisma.product.create({ data: p })
  }
  console.log('✅ Genshin products seeded')

  console.log('\n🎮 Database seeded successfully!')
  console.log('Admin: admin@gameshop.vn / Admin@123456')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
