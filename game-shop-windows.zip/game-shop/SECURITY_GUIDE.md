# 🔐 HƯỚNG DẪN CẤU HÌNH BẢO MẬT TOÀN DIỆN

## 1. Cloudflare Anti-DDoS Setup

### Bước 1: Thêm domain vào Cloudflare
1. Đăng ký tại [cloudflare.com](https://cloudflare.com)
2. Add site → nhập domain của bạn
3. Cloudflare scan DNS records
4. Thay nameserver của domain thành của Cloudflare
5. Chờ propagation (5-30 phút)

### Bước 2: Cấu hình DNS
```
Type: A
Name: @
Content: IP_SERVER_CỦA_BẠN
Proxy: ✅ Proxied (đám mây CAM - bắt buộc)

Type: A  
Name: www
Content: IP_SERVER_CỦA_BẠN
Proxy: ✅ Proxied

Type: A
Name: api  
Content: IP_SERVER_CỦA_BẠN
Proxy: ✅ Proxied
```

### Bước 3: SSL/TLS
- SSL/TLS → Overview → chọn **Full (Strict)**
- Edge Certificates → Always Use HTTPS: **ON**
- Minimum TLS Version: **TLS 1.2**
- HSTS: Enable (max-age=31536000)

### Bước 4: WAF Rules (Firewall Rules)
Vào **Security → WAF → Custom rules** → Create rule:

**Rule 1: Block Bad Bots**
```
Field: Known Bots
Operator: equals
Value: false
AND
Field: Bot Score
Operator: less than  
Value: 30
Action: Block
```

**Rule 2: Rate Limit Login**
```
Field: URI Path
Operator: equals
Value: /api/auth/register
AND
Field: Rate
Operator: greater than
Value: 10 req/minute per IP
Action: Block (1 hour)
```

**Rule 3: Rate Limit Recharge**
```
Field: URI Path
Operator: contains
Value: /api/recharge
Action: Rate Limit → 20 req/5min per IP
```

**Rule 4: Block Suspicious Countries (Optional)**
```
Field: Country
Operator: is in
Value: [CN, RU, KP] (chỉnh theo nhu cầu)
AND
Field: Threat Score
Operator: greater than
Value: 50
Action: Challenge (CAPTCHA)
```

### Bước 5: DDoS Protection Settings
- Security → DDoS → HTTP DDoS attack protection
  - Sensitivity Level: **High**
  - Action: **Block**

### Bước 6: Under Attack Mode
- Khi bị tấn công: Security → Settings → Security Level → **I'm Under Attack!**
- Bình thường: **Medium**

### Bước 7: Bot Fight Mode
- Security → Bots → Bot Fight Mode: **ON**
- Super Bot Fight Mode (Pro+): Block definitely automated + verified bots

### Bước 8: Page Rules
```
URL: */api/recharge/*
Settings:
  - Cache Level: Bypass
  - Disable Security: OFF
```

---

## 2. Server-Side Security (Next.js)

### Rate Limiting (đã tích hợp trong src/lib/rateLimit.ts)
- Login: 5 requests/phút/IP
- Recharge: 10 requests/5 phút/IP  
- API: 60 requests/phút/IP

### CSRF Protection
Next.js App Router có built-in CSRF protection qua SameSite cookies của NextAuth.

### SQL Injection Prevention
Prisma ORM tự động parameterized queries → không cần lo SQL injection.

### XSS Prevention
- Next.js auto-escapes output
- Content-Security-Policy header (cấu hình trong next.config.js)

### Input Validation
Zod schema validation trên tất cả API endpoints.

---

## 3. Environment Variables Security

```bash
# .env KHÔNG commit lên git!
echo ".env" >> .gitignore
echo ".env.local" >> .gitignore
```

### Secrets cần rotate định kỳ:
- `NEXTAUTH_SECRET` (mỗi 90 ngày)
- `BANK_WEBHOOK_SECRET` (mỗi 90 ngày)
- `CARD_API_KEY` (theo yêu cầu đối tác)

---

## 4. Database Security

```sql
-- Tạo user DB riêng với quyền hạn chế
CREATE USER gameshop_user WITH PASSWORD 'strong_password';
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO gameshop_user;
-- KHÔNG grant DROP, CREATE, TRUNCATE
```

### Backup tự động (crontab):
```bash
0 2 * * * pg_dump -U postgres gameshop | gzip > /backup/gameshop_$(date +%Y%m%d).sql.gz
find /backup -name "*.sql.gz" -mtime +30 -delete
```

---

## 5. SePay Webhook Setup

1. Đăng ký tại [sepay.vn](https://sepay.vn)
2. Liên kết tài khoản ngân hàng
3. Settings → Webhook:
   - URL: `https://yourdomain.com/api/recharge/bank/webhook`
   - Secret Key: điền vào `BANK_WEBHOOK_SECRET`
4. Test webhook với SePay simulator

---

## 6. Deployment Checklist

```bash
# Production build
npm run build

# Start với PM2
npm install -g pm2
pm2 start ecosystem.config.js
pm2 startup
pm2 save

# Nginx reverse proxy
# Xem ecosystem.config.js
```

### ecosystem.config.js
```js
module.exports = {
  apps: [{
    name: 'gameshop',
    script: 'node_modules/.bin/next',
    args: 'start',
    cwd: '/var/www/gameshop',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
    },
    instances: 2,
    exec_mode: 'cluster',
    max_memory_restart: '500M',
    error_file: '/var/log/gameshop/error.log',
    out_file: '/var/log/gameshop/out.log',
  }],
}
```

### Nginx config
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com;
    
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    
    # Security headers
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 7. Cài Đặt Từng Bước

```bash
# 1. Clone/setup
git clone <repo> && cd game-shop

# 2. Install dependencies
npm install

# 3. Setup env
cp .env.example .env
# Chỉnh sửa .env với thông tin thực

# 4. Setup database PostgreSQL
createdb gameshop
npm run db:push
npm run db:seed

# 5. Development
npm run dev

# 6. Production
npm run build
npm start
```
