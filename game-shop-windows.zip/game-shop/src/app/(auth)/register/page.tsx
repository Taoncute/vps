// src/app/(auth)/register/page.tsx
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Loader2, Eye, EyeOff, UserPlus } from 'lucide-react'

export default function RegisterPage() {
  const router = useRouter()
  const [form, setForm] = useState({ username: '', email: '', password: '', confirm: '' })
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [k]: e.target.value }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.password !== form.confirm) {
      toast.error('Mật khẩu xác nhận không khớp')
      return
    }
    if (form.password.length < 8) {
      toast.error('Mật khẩu phải có ít nhất 8 ký tự')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: form.username,
          email: form.email.toLowerCase(),
          password: form.password,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Đăng ký thất bại')
      toast.success('Đăng ký thành công! Đang chuyển hướng...')
      router.push('/login')
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 grid-bg">
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-neon-purple/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 left-1/4 w-96 h-96 bg-neon-gold/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <Link href="/" className="inline-block">
            <span className="font-display font-black text-3xl">
              <span className="text-neon-cyan">GAME</span>
              <span className="text-white">SHOP</span>
              <span className="text-neon-gold"> VN</span>
            </span>
          </Link>
          <p className="text-white/50 text-sm mt-2">Tạo tài khoản mới</p>
        </div>

        <div className="glass-card p-8">
          <h1 className="font-display font-bold text-xl text-white mb-6 uppercase tracking-wider">
            Đăng Ký
          </h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { key: 'username', label: 'Tên Đăng Nhập', type: 'text', placeholder: 'gameplayer123' },
              { key: 'email', label: 'Email', type: 'email', placeholder: 'your@email.com' },
            ].map((f) => (
              <div key={f.key}>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                  {f.label}
                </label>
                <input
                  type={f.type}
                  value={form[f.key as keyof typeof form]}
                  onChange={handleChange(f.key)}
                  required
                  placeholder={f.placeholder}
                  className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-neon-cyan/60 transition-colors"
                />
              </div>
            ))}

            {['password', 'confirm'].map((k) => (
              <div key={k}>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                  {k === 'password' ? 'Mật Khẩu' : 'Xác Nhận Mật Khẩu'}
                </label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={form[k as keyof typeof form]}
                    onChange={handleChange(k)}
                    required
                    minLength={8}
                    placeholder="Ít nhất 8 ký tự"
                    className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 pr-10 text-white text-sm focus:outline-none focus:border-neon-cyan/60 transition-colors"
                  />
                  {k === 'password' && (
                    <button
                      type="button"
                      onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                    >
                      {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  )}
                </div>
              </div>
            ))}

            <p className="text-xs text-white/40">
              Bằng cách đăng ký, bạn đồng ý với{' '}
              <Link href="/terms" className="text-neon-cyan hover:underline">Điều khoản dịch vụ</Link>
            </p>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-neon py-3 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? <Loader2 size={16} className="animate-spin" /> : <UserPlus size={16} />}
              {loading ? 'Đang đăng ký...' : 'Tạo Tài Khoản'}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-white/50">
            Đã có tài khoản?{' '}
            <Link href="/login" className="text-neon-cyan hover:underline font-semibold">
              Đăng nhập
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
