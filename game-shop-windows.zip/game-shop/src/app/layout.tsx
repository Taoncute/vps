// src/app/layout.tsx
import type { Metadata } from 'next'
import './globals.css'
import { Providers } from '@/components/Providers'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  title: {
    default: 'GameShop VN - Shop Game Uy Tín #1 Việt Nam',
    template: '%s | GameShop VN',
  },
  description:
    'Mua bán tài khoản Roblox, Genshin Impact, nạp Robux, Genesis Crystals giá rẻ. Giao dịch tự động 24/7, bảo đảm uy tín.',
  keywords: [
    'shop roblox', 'mua acc blox fruits', 'genshin impact', 'nạp genesis crystals',
    'robux giá rẻ', 'acc genshin', 'shop game uy tín',
  ],
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: process.env.NEXT_PUBLIC_APP_URL,
    siteName: 'GameShop VN',
    title: 'GameShop VN - Shop Game Uy Tín #1 Việt Nam',
    description: 'Mua bán tài khoản game, nạp thẻ game giá rẻ uy tín.',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi" className="dark">
      <body className="min-h-screen bg-dark-900 text-white font-body antialiased">
        <Providers>
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#0F0F1E',
                color: '#fff',
                border: '1px solid rgba(0,245,255,0.2)',
                fontFamily: 'Rajdhani, sans-serif',
                fontSize: '14px',
              },
              success: {
                iconTheme: { primary: '#00FF88', secondary: '#050508' },
              },
              error: {
                iconTheme: { primary: '#FF4444', secondary: '#050508' },
              },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
