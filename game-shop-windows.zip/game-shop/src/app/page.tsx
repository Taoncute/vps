// src/app/page.tsx
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'
import { HeroBanner } from '@/components/HeroBanner'
import { FeaturedProducts } from '@/components/FeaturedProducts'
import { TopRechargeBoard } from '@/components/TopRechargeBoard'
import { AnnouncementTicker } from '@/components/AnnouncementTicker'
import { GameSection } from '@/components/GameSection'
import { TrustBadges } from '@/components/TrustBadges'
import { prisma } from '@/lib/prisma'

export const revalidate = 60

async function getHomeData() {
  const [featuredProducts, topRecharge, announcements, robloxProducts, genshinProducts] =
    await Promise.all([
      prisma.product.findMany({
        where: { isActive: true, isFeatured: true },
        orderBy: { sold: 'desc' },
        take: 6,
      }),
      prisma.user.findMany({
        where: { totalRecharge: { gt: 0 } },
        orderBy: { totalRecharge: 'desc' },
        take: 10,
        select: { username: true, totalRecharge: true, avatar: true },
      }),
      prisma.announcement.findMany({
        where: { isActive: true },
        orderBy: { createdAt: 'desc' },
        take: 5,
      }),
      prisma.product.findMany({
        where: { isActive: true, game: 'ROBLOX' },
        orderBy: { sold: 'desc' },
        take: 4,
      }),
      prisma.product.findMany({
        where: { isActive: true, game: 'GENSHIN' },
        orderBy: { sold: 'desc' },
        take: 4,
      }),
    ])

  return { featuredProducts, topRecharge, announcements, robloxProducts, genshinProducts }
}

export default async function HomePage() {
  const data = await getHomeData()

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <AnnouncementTicker announcements={data.announcements} />
      <main className="flex-1">
        <HeroBanner />
        <TrustBadges />

        {/* Featured Products */}
        <section className="py-16 container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="section-title">⚡ Nổi Bật</h2>
            <a href="/products/roblox" className="text-sm text-neon-cyan hover:underline font-semibold">
              Xem tất cả →
            </a>
          </div>
          <FeaturedProducts products={data.featuredProducts} />
        </section>

        {/* Roblox Section */}
        <section className="py-16 bg-dark-800/50">
          <div className="container mx-auto px-4">
            <GameSection
              game="ROBLOX"
              products={data.robloxProducts}
              title="🎮 ROBLOX"
              subtitle="Blox Fruits · Robux · Dịch Vụ"
              href="/products/roblox"
              accentColor="from-red-600 to-orange-500"
            />
          </div>
        </section>

        {/* Genshin Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <GameSection
              game="GENSHIN"
              products={data.genshinProducts}
              title="✨ GENSHIN IMPACT"
              subtitle="Tài Khoản · Genesis Crystals · Cày Thuê"
              href="/products/genshin"
              accentColor="from-violet-600 to-pink-500"
            />
          </div>
        </section>

        {/* Top Recharge + Trust */}
        <section className="py-16 bg-dark-800/50">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12">
              <TopRechargeBoard users={data.topRecharge} />
              <div className="space-y-6">
                <h2 className="section-title">💎 Tại Sao Chọn Chúng Tôi?</h2>
                {[
                  { icon: '⚡', title: 'Tự Động 24/7', desc: 'Hệ thống giao dịch tự động, nhận hàng ngay sau khi thanh toán' },
                  { icon: '🔒', title: 'Bảo Mật Cao', desc: 'Cloudflare Anti-DDoS, mã hóa SSL, bảo vệ toàn diện' },
                  { icon: '💳', title: 'Thanh Toán Đa Dạng', desc: 'Thẻ cào, chuyển khoản ngân hàng, VietQR tiện lợi' },
                  { icon: '🛡️', title: 'Bảo Hành Uy Tín', desc: 'Cam kết hoàn tiền 100% nếu sản phẩm lỗi' },
                ].map((item) => (
                  <div key={item.title} className="flex gap-4 glass-card p-4">
                    <div className="text-3xl flex-shrink-0">{item.icon}</div>
                    <div>
                      <div className="font-display font-bold text-white mb-1">{item.title}</div>
                      <div className="text-sm text-white/60">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
