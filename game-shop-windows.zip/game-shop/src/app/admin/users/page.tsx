// src/app/admin/users/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { formatCurrency, formatDate } from '@/lib/utils'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Loader2, Search, RefreshCw, DollarSign } from 'lucide-react'

export default function AdminUsers() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [users, setUsers] = useState<any[]>([])
  const [total, setTotal] = useState(0)
  const [pages, setPages] = useState(1)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [adjustModal, setAdjustModal] = useState<any>(null)
  const [adjustAmount, setAdjustAmount] = useState('')
  const [adjustNote, setAdjustNote] = useState('')
  const [adjusting, setAdjusting] = useState(false)

  useEffect(() => {
    if (status === 'loading') return
    if (!session || session.user.role !== 'ADMIN') { router.push('/'); return }
    fetchUsers()
  }, [session, status, page])

  const fetchUsers = async () => {
    setLoading(true)
    const params = new URLSearchParams({ page: String(page) })
    if (search) params.set('q', search)
    const res = await fetch(`/api/admin/users?${params}`)
    const data = await res.json()
    setUsers(data.users || [])
    setTotal(data.total || 0)
    setPages(data.pages || 1)
    setLoading(false)
  }

  const handleAdjust = async () => {
    const amount = Number(adjustAmount)
    if (isNaN(amount) || amount === 0) { toast.error('Số tiền không hợp lệ'); return }
    setAdjusting(true)
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: adjustModal.id, amount, note: adjustNote }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success(`Đã điều chỉnh số dư: ${formatCurrency(amount)}`)
      setAdjustModal(null)
      setAdjustAmount('')
      setAdjustNote('')
      fetchUsers()
    } catch (e: any) { toast.error(e.message) }
    setAdjusting(false)
  }

  return (
    <div className="min-h-screen bg-dark-900">
      <header className="bg-dark-800 border-b border-white/5 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="font-display font-black text-lg">
            <span className="text-neon-cyan">GAME</span><span className="text-white">SHOP</span><span className="text-neon-gold"> ADMIN</span>
          </Link>
          <nav className="hidden md:flex gap-1">
            {[{label:'Dashboard',href:'/admin'},{label:'Sản Phẩm',href:'/admin/products'},{label:'Đơn Hàng',href:'/admin/transactions'},{label:'Người Dùng',href:'/admin/users'}].map(l=>(
              <Link key={l.href} href={l.href} className="px-3 py-1.5 rounded-lg text-sm font-semibold text-white/70 hover:text-neon-cyan hover:bg-white/5">{l.label}</Link>
            ))}
          </nav>
        </div>
        <Link href="/" className="text-sm text-white/50 hover:text-white">← Về Shop</Link>
      </header>

      <main className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display font-bold text-2xl text-white uppercase tracking-wider">Quản Lý Người Dùng</h1>
            <p className="text-white/40 text-sm mt-1">{total} tài khoản</p>
          </div>
          <button onClick={fetchUsers} className="p-2 rounded-lg glass-card text-white/50 hover:text-white"><RefreshCw size={16} /></button>
        </div>

        <div className="flex gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
            <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && fetchUsers()}
              placeholder="Tìm theo username hoặc email..."
              className="w-full bg-dark-600 border border-white/10 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-neon-cyan/50" />
          </div>
          <button onClick={() => { setPage(1); fetchUsers() }} className="btn-outline-neon py-2 px-4 text-sm">Tìm</button>
        </div>

        <div className="glass-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 text-white/40 text-xs uppercase tracking-wider">
                <th className="text-left px-4 py-3">Người Dùng</th>
                <th className="text-right px-4 py-3 hidden md:table-cell">Số Dư</th>
                <th className="text-right px-4 py-3 hidden md:table-cell">Đã Nạp</th>
                <th className="text-right px-4 py-3 hidden lg:table-cell">Đã Chi</th>
                <th className="text-center px-4 py-3">Role</th>
                <th className="text-right px-4 py-3">Thao Tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={6} className="text-center py-12"><Loader2 className="animate-spin mx-auto text-neon-cyan" /></td></tr>
              ) : users.map(u => (
                <tr key={u.id} className="hover:bg-white/3 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-bold text-white">{u.username}</div>
                    <div className="text-xs text-white/40">{u.email}</div>
                    <div className="text-xs text-white/30 mt-0.5">{formatDate(u.createdAt)}</div>
                  </td>
                  <td className="px-4 py-3 text-right hidden md:table-cell">
                    <span className="font-mono font-bold text-neon-gold">{formatCurrency(u.balance)}</span>
                  </td>
                  <td className="px-4 py-3 text-right hidden md:table-cell text-white/60 font-mono">{formatCurrency(u.totalRecharge)}</td>
                  <td className="px-4 py-3 text-right hidden lg:table-cell text-white/60 font-mono">{formatCurrency(u.totalSpent)}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${u.role === 'ADMIN' ? 'bg-neon-purple/20 text-neon-purple' : 'bg-dark-600 text-white/50'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => setAdjustModal(u)} className="p-1.5 rounded hover:bg-neon-gold/10 text-neon-gold" title="Điều chỉnh số dư">
                      <DollarSign size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {pages > 1 && (
          <div className="flex justify-center gap-2 mt-4">
            {Array.from({ length: pages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={`w-9 h-9 rounded-lg text-sm font-bold ${page === p ? 'bg-neon-cyan text-dark-900' : 'glass-card text-white/60'}`}>{p}</button>
            ))}
          </div>
        )}
      </main>

      {adjustModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="glass-card w-full max-w-md p-6">
            <h2 className="font-display font-bold text-xl text-white mb-1 uppercase tracking-wider">Điều Chỉnh Số Dư</h2>
            <p className="text-white/50 text-sm mb-5">User: <span className="text-neon-cyan font-bold">{adjustModal.username}</span> · Hiện tại: <span className="text-neon-gold font-mono">{formatCurrency(adjustModal.balance)}</span></p>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1 block">Số Tiền (âm = trừ)</label>
                <input type="number" value={adjustAmount} onChange={e => setAdjustAmount(e.target.value)}
                  placeholder="+100000 hoặc -50000"
                  className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-neon-cyan/50 font-mono" />
              </div>
              <div>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1 block">Ghi Chú</label>
                <input type="text" value={adjustNote} onChange={e => setAdjustNote(e.target.value)}
                  placeholder="Lý do điều chỉnh..."
                  className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-neon-cyan/50" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setAdjustModal(null)} className="flex-1 btn-outline-neon py-2.5">Hủy</button>
              <button onClick={handleAdjust} disabled={adjusting} className="flex-1 btn-neon py-2.5 flex items-center justify-center gap-2">
                {adjusting ? <Loader2 size={16} className="animate-spin" /> : <DollarSign size={16} />}
                {adjusting ? 'Đang Xử Lý...' : 'Xác Nhận'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
