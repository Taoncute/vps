// src/app/admin/products/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { formatCurrency, formatDate } from '@/lib/utils'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Plus, Edit2, Trash2, Loader2, Search, RefreshCw, Package } from 'lucide-react'

export default function AdminProducts() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [products, setProducts] = useState<any[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [gameFilter, setGameFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editProduct, setEditProduct] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    name: '', description: '', price: 0, originalPrice: 0,
    game: 'ROBLOX', category: 'account', stock: 0,
    isActive: true, isFeatured: false, metadata: '{}'
  })

  useEffect(() => {
    if (status === 'loading') return
    if (!session || session.user.role !== 'ADMIN') { router.push('/'); return }
    fetchProducts()
  }, [session, status, page, gameFilter])

  const fetchProducts = async () => {
    setLoading(true)
    const params = new URLSearchParams({ page: String(page) })
    if (gameFilter) params.set('game', gameFilter)
    const res = await fetch(`/api/admin/products?${params}`)
    const data = await res.json()
    setProducts(data.products || [])
    setTotal(data.total || 0)
    setPages(data.pages || 1)
    setLoading(false)
  }

  const openEdit = (p: any) => {
    setEditProduct(p)
    setForm({
      name: p.name, description: p.description || '', price: p.price,
      originalPrice: p.originalPrice || 0, game: p.game, category: p.category,
      stock: p.stock, isActive: p.isActive, isFeatured: p.isFeatured,
      metadata: JSON.stringify(p.metadata || {}, null, 2)
    })
    setShowModal(true)
  }

  const openCreate = () => {
    setEditProduct(null)
    setForm({ name: '', description: '', price: 0, originalPrice: 0, game: 'ROBLOX', category: 'account', stock: 0, isActive: true, isFeatured: false, metadata: '{}' })
    setShowModal(true)
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      let metadata = {}
      try { metadata = JSON.parse(form.metadata) } catch {}
      const body = { ...form, metadata, price: Number(form.price), originalPrice: Number(form.originalPrice) || undefined, stock: Number(form.stock), ...(editProduct ? { id: editProduct.id } : {}) }
      const res = await fetch('/api/admin/products', {
        method: editProduct ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success(editProduct ? 'Đã cập nhật sản phẩm' : 'Đã tạo sản phẩm mới')
      setShowModal(false)
      fetchProducts()
    } catch (e: any) { toast.error(e.message) }
    setSaving(false)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Ẩn sản phẩm này?')) return
    await fetch(`/api/admin/products?id=${id}`, { method: 'DELETE' })
    toast.success('Đã ẩn sản phẩm')
    fetchProducts()
  }

  return (
    <div className="min-h-screen bg-dark-900">
      <header className="bg-dark-800 border-b border-white/5 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="font-display font-black text-lg">
            <span className="text-neon-cyan">GAME</span><span className="text-white">SHOP</span><span className="text-neon-gold"> ADMIN</span>
          </Link>
          <nav className="hidden md:flex gap-1">
            {[{label:'Dashboard',href:'/admin'},{label:'Sản Phẩm',href:'/admin/products'},{label:'Đơn Hàng',href:'/admin/transactions'},{label:'Người Dùng',href:'/admin/users'}].map(l=>(
              <Link key={l.href} href={l.href} className="px-3 py-1.5 rounded-lg text-sm font-semibold text-white/70 hover:text-neon-cyan hover:bg-white/5">{l.label}</Link>
            ))}
          </nav>
        </div>
        <Link href="/" className="text-sm text-white/50 hover:text-white">← Về Shop</Link>
      </header>

      <main className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display font-bold text-2xl text-white uppercase tracking-wider">Quản Lý Sản Phẩm</h1>
            <p className="text-white/40 text-sm mt-1">{total} sản phẩm</p>
          </div>
          <div className="flex gap-2">
            <button onClick={fetchProducts} className="p-2 rounded-lg glass-card text-white/50 hover:text-white"><RefreshCw size={16} /></button>
            <button onClick={openCreate} className="btn-neon flex items-center gap-2 py-2 px-4 text-sm"><Plus size={16} /> Thêm SP</button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-4">
          {['', 'ROBLOX', 'GENSHIN', 'OTHER'].map(g => (
            <button key={g} onClick={() => { setGameFilter(g); setPage(1) }}
              className={`px-3 py-1.5 rounded-lg text-sm font-bold border transition-all ${gameFilter === g ? 'bg-neon-cyan text-dark-900 border-neon-cyan' : 'border-white/10 text-white/60 hover:border-neon-cyan/40'}`}>
              {g || 'Tất Cả'}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="glass-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 text-white/40 text-xs uppercase tracking-wider">
                <th className="text-left px-4 py-3">Sản Phẩm</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Game</th>
                <th className="text-right px-4 py-3">Giá</th>
                <th className="text-right px-4 py-3">Kho</th>
                <th className="text-right px-4 py-3">Đã Bán</th>
                <th className="text-center px-4 py-3 hidden md:table-cell">Trạng Thái</th>
                <th className="text-right px-4 py-3">Thao Tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={7} className="text-center py-12"><Loader2 className="animate-spin mx-auto text-neon-cyan" /></td></tr>
              ) : products.map(p => (
                <tr key={p.id} className="hover:bg-white/3 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-semibold text-white">{p.name}</div>
                    <div className="text-xs text-white/40">{p.category}</div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <span className={p.game === 'ROBLOX' ? 'badge-roblox' : 'badge-genshin'}>{p.game}</span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-neon-gold">{formatCurrency(p.price)}</td>
                  <td className="px-4 py-3 text-right">
                    <span className={`font-mono font-bold ${p.stock <= 5 ? 'text-orange-400' : 'text-white'}`}>{p.stock}</span>
                  </td>
                  <td className="px-4 py-3 text-right text-white/60 font-mono">{p.sold}</td>
                  <td className="px-4 py-3 text-center hidden md:table-cell">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${p.isActive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                      {p.isActive ? 'Active' : 'Ẩn'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-2">
                      <button onClick={() => openEdit(p)} className="p-1.5 rounded hover:bg-neon-cyan/10 text-neon-cyan"><Edit2 size={14} /></button>
                      <button onClick={() => handleDelete(p.id)} className="p-1.5 rounded hover:bg-red-500/10 text-red-400"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div className="flex justify-center gap-2 mt-4">
            {Array.from({ length: pages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={`w-9 h-9 rounded-lg text-sm font-bold ${page === p ? 'bg-neon-cyan text-dark-900' : 'glass-card text-white/60'}`}>
                {p}
              </button>
            ))}
          </div>
        )}
      </main>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="glass-card w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <h2 className="font-display font-bold text-xl text-white mb-5 uppercase tracking-wider">
              {editProduct ? 'Sửa Sản Phẩm' : 'Thêm Sản Phẩm'}
            </h2>
            <div className="space-y-4">
              {[
                { key: 'name', label: 'Tên Sản Phẩm', type: 'text' },
                { key: 'description', label: 'Mô Tả', type: 'textarea' },
                { key: 'price', label: 'Giá (VND)', type: 'number' },
                { key: 'originalPrice', label: 'Giá Gốc (tùy chọn)', type: 'number' },
                { key: 'stock', label: 'Số Lượng Kho', type: 'number' },
              ].map(f => (
                <div key={f.key}>
                  <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1 block">{f.label}</label>
                  {f.type === 'textarea' ? (
                    <textarea value={(form as any)[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      className="w-full bg-dark-600 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neon-cyan/50 h-20 resize-none" />
                  ) : (
                    <input type={f.type} value={(form as any)[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: f.type === 'number' ? e.target.value : e.target.value }))}
                      className="w-full bg-dark-600 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neon-cyan/50" />
                  )}
                </div>
              ))}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1 block">Game</label>
                  <select value={form.game} onChange={e => setForm(p => ({ ...p, game: e.target.value }))}
                    className="w-full bg-dark-600 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none">
                    <option value="ROBLOX">ROBLOX</option>
                    <option value="GENSHIN">GENSHIN</option>
                    <option value="OTHER">OTHER</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1 block">Danh Mục</label>
                  <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                    className="w-full bg-dark-600 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none">
                    <option value="account">Tài Khoản</option>
                    <option value="robux">Robux</option>
                    <option value="crystal">Genesis Crystals</option>
                    <option value="service">Dịch Vụ</option>
                  </select>
                </div>
              </div>
              <div className="flex gap-6">
                {[{ key: 'isActive', label: 'Hiển Thị' }, { key: 'isFeatured', label: 'Nổi Bật' }].map(f => (
                  <label key={f.key} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={(form as any)[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.checked }))}
                      className="w-4 h-4 rounded" />
                    <span className="text-sm text-white/70">{f.label}</span>
                  </label>
                ))}
              </div>
              <div>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1 block">Metadata (JSON)</label>
                <textarea value={form.metadata} onChange={e => setForm(p => ({ ...p, metadata: e.target.value }))}
                  className="w-full bg-dark-600 border border-white/10 rounded-lg px-3 py-2 text-white text-xs font-mono focus:outline-none focus:border-neon-cyan/50 h-24 resize-none" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 btn-outline-neon py-2.5">Hủy</button>
              <button onClick={handleSave} disabled={saving} className="flex-1 btn-neon py-2.5 flex items-center justify-center gap-2">
                {saving ? <Loader2 size={16} className="animate-spin" /> : null}
                {saving ? 'Đang Lưu...' : 'Lưu'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
