// src/app/admin/recharges/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { formatCurrency, formatDate } from '@/lib/utils'

export default function AdminRechargesPage() {
  const [recharges, setRecharges] = useState<any[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)

  useEffect(() => {
    setLoading(true)
    fetch(`/api/admin/recharges?page=${page}`)
      .then((r) => r.json())
      .then((d) => { setRecharges(d.recharges || []); setTotal(d.total || 0) })
      .finally(() => setLoading(false))
  }, [page])

  const statusColor: Record<string, string> = {
    SUCCESS: 'text-neon-green',
    PENDING: 'text-neon-gold',
    FAILED: 'text-red-400',
    FRAUDULENT: 'text-red-600',
  }
  const methodLabel: Record<string, string> = {
    CARD: '🃏 Thẻ Cào',
    BANK_TRANSFER: '🏦 CK Ngân Hàng',
    ADMIN: '👤 Admin',
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="font-display font-bold text-2xl text-white uppercase tracking-wider">Lịch Sử Nạp Tiền</h1>
        <p className="text-white/40 text-sm mt-1">{total} giao dịch nạp tiền</p>
      </div>

      <div className="glass-card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/5 text-left">
              {['Người Dùng', 'Phương Thức', 'Mệnh Giá', 'Nhận Được', 'Trạng Thái', 'Thời Gian'].map((h) => (
                <th key={h} className="px-4 py-3 text-xs font-bold text-white/40 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {loading ? (
              [...Array(8)].map((_, i) => (
                <tr key={i}>{[...Array(6)].map((_, j) => <td key={j} className="px-4 py-3"><div className="h-4 rounded shimmer" /></td>)}</tr>
              ))
            ) : recharges.map((r: any) => (
              <tr key={r.id} className="hover:bg-white/2">
                <td className="px-4 py-3 font-bold text-white">{r.user?.username}</td>
                <td className="px-4 py-3 text-white/70 text-xs">{methodLabel[r.method] || r.method}</td>
                <td className="px-4 py-3 font-mono text-white/60 text-xs">{formatCurrency(r.rawAmount)}</td>
                <td className="px-4 py-3 price-tag text-sm">{formatCurrency(r.amount)}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-bold ${statusColor[r.status] || 'text-white/40'}`}>{r.status}</span>
                </td>
                <td className="px-4 py-3 text-white/40 text-xs">{formatDate(r.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {Math.ceil(total / 20) > 1 && (
        <div className="flex justify-center gap-2 mt-6">
          {Array.from({ length: Math.ceil(total / 20) }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => setPage(p)}
              className={`w-9 h-9 flex items-center justify-center rounded-lg text-sm font-bold transition-all ${
                page === p ? 'bg-neon-cyan text-dark-900' : 'glass-card text-white/60 hover:text-neon-cyan'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
