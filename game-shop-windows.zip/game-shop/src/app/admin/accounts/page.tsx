// src/app/admin/accounts/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { formatDate } from '@/lib/utils'
import toast from 'react-hot-toast'
import { Upload, Trash2, X, Loader2, ChevronDown } from 'lucide-react'

export default function AdminAccountsPage() {
  const [products, setProducts] = useState<any[]>([])
  const [selectedProductId, setSelectedProductId] = useState('')
  const [accounts, setAccounts] = useState<any[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [statusFilter, setStatusFilter] = useState('')
  const [showImport, setShowImport] = useState(false)
  const [rawInput, setRawInput] = useState('')
  const [importing, setImporting] = useState(false)

  useEffect(() => {
    fetch('/api/admin/products?take=100')
      .then((r) => r.json())
      .then((d) => setProducts(d.products?.filter((p: any) => p.category === 'account') || []))
  }, [])

  useEffect(() => {
    if (!selectedProductId) return
    setLoading(true)
    const params = new URLSearchParams({ productId: selectedProductId })
    if (statusFilter) params.set('status', statusFilter)
    fetch(`/api/admin/accounts?${params}`)
      .then((r) => r.json())
      .then((d) => { setAccounts(d.accounts || []); setTotal(d.total || 0) })
      .finally(() => setLoading(false))
  }, [selectedProductId, statusFilter])

  const handleImport = async () => {
    if (!selectedProductId || !rawInput.trim()) {
      toast.error('Chọn sản phẩm và nhập dữ liệu tài khoản')
      return
    }
    setImporting(true)
    try {
      const res = await fetch('/api/admin/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: selectedProductId, raw: rawInput }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success(`Đã import ${data.imported} tài khoản!`)
      setShowImport(false)
      setRawInput('')
      setLoading(true)
      fetch(`/api/admin/accounts?productId=${selectedProductId}`)
        .then((r) => r.json())
        .then((d) => { setAccounts(d.accounts || []); setTotal(d.total || 0) })
        .finally(() => setLoading(false))
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setImporting(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Xóa tài khoản này?')) return
    const res = await fetch(`/api/admin/accounts?id=${id}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success('Đã xóa')
      setAccounts((prev) => prev.filter((a) => a.id !== id))
      setTotal((t) => t - 1)
    } else {
      const d = await res.json()
      toast.error(d.error)
    }
  }

  const statusColor: Record<string, string> = {
    AVAILABLE: 'text-neon-green',
    RESERVED: 'text-neon-gold',
    SOLD: 'text-white/40',
  }
  const statusLabel: Record<string, string> = {
    AVAILABLE: 'Còn hàng',
    RESERVED: 'Đặt trước',
    SOLD: 'Đã bán',
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-bold text-2xl text-white uppercase tracking-wider">Kho Tài Khoản</h1>
          <p className="text-white/40 text-sm mt-1">{total} tài khoản</p>
        </div>
        {selectedProductId && (
          <button onClick={() => setShowImport(true)} className="btn-neon flex items-center gap-2">
            <Upload size={15} /> Import Tài Khoản
          </button>
        )}
      </div>

      {/* Product selector */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative">
          <select
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            className="appearance-none bg-dark-600 border border-white/10 rounded-lg px-4 py-2 pr-8 text-sm text-white focus:outline-none focus:border-neon-cyan/50"
          >
            <option value="">-- Chọn sản phẩm --</option>
            {products.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
          <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
        </div>

        {['', 'AVAILABLE', 'SOLD'].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all ${
              statusFilter === s ? 'bg-neon-cyan text-dark-900 border-neon-cyan' : 'border-white/10 text-white/60'
            }`}
          >
            {s ? statusLabel[s] : 'Tất Cả'}
          </button>
        ))}
      </div>

      {/* Table */}
      {selectedProductId ? (
        <div className="glass-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 text-left">
                {['Username', 'Password', 'Email', 'Trạng Thái', 'Ngày Thêm', ''].map((h) => (
                  <th key={h} className="px-4 py-3 text-xs font-bold text-white/40 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i}>{[...Array(6)].map((_, j) => <td key={j} className="px-4 py-3"><div className="h-4 rounded shimmer" /></td>)}</tr>
                ))
              ) : accounts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-white/30">
                    Không có tài khoản nào
                  </td>
                </tr>
              ) : accounts.map((a) => (
                <tr key={a.id} className="hover:bg-white/2">
                  <td className="px-4 py-3 font-mono text-white text-xs">{a.username}</td>
                  <td className="px-4 py-3 font-mono text-white/60 text-xs">{a.password}</td>
                  <td className="px-4 py-3 text-white/50 text-xs">{a.email || '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-bold ${statusColor[a.status] || 'text-white/40'}`}>
                      {statusLabel[a.status] || a.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-white/40 text-xs">{formatDate(a.createdAt)}</td>
                  <td className="px-4 py-3">
                    {a.status === 'AVAILABLE' && (
                      <button onClick={() => handleDelete(a.id)} className="p-1.5 rounded hover:bg-red-500/10 text-red-400 transition-colors">
                        <Trash2 size={13} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-20 text-white/30">
          <div className="text-4xl mb-3">📦</div>
          <div className="font-display uppercase tracking-wider">Chọn sản phẩm để xem kho</div>
        </div>
      )}

      {/* Import Modal */}
      {showImport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-dark-700 border border-white/10 rounded-2xl w-full max-w-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
              <h2 className="font-display font-bold text-white uppercase tracking-wider text-sm">Import Tài Khoản</h2>
              <button onClick={() => setShowImport(false)}><X size={18} className="text-white/40" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="glass-card p-3 text-xs text-white/60 space-y-1">
                <div className="font-bold text-white/80 mb-1">Định dạng (mỗi dòng 1 tài khoản):</div>
                <div className="font-mono">username|password</div>
                <div className="font-mono text-white/40">username|password|email|emailpass</div>
              </div>
              <textarea
                value={rawInput}
                onChange={(e) => setRawInput(e.target.value)}
                rows={12}
                placeholder={'acc1|pass1\nacc2|pass2|email@gmail.com|emailpass123\n...'}
                className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-3 text-white text-xs font-mono focus:outline-none focus:border-neon-cyan/50 resize-none"
              />
              <div className="text-xs text-white/40">
                Sẽ import <span className="text-neon-cyan font-bold">{rawInput.split('\n').filter((l) => l.trim().includes('|')).length}</span> tài khoản
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowImport(false)} className="flex-1 btn-outline-neon">Huỷ</button>
                <button onClick={handleImport} disabled={importing} className="flex-1 btn-neon flex items-center justify-center gap-2 disabled:opacity-50">
                  {importing ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                  Import
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
