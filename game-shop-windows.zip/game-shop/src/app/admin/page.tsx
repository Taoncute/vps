// src/app/admin/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { formatCurrency, formatDate } from '@/lib/utils'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'
import {
  Users, ShoppingBag, TrendingUp, Wallet,
  Package, CreditCard, Star,
} from 'lucide-react'

export default function AdminDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/admin/stats')
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="p-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-28 rounded-xl shimmer" />
          ))}
        </div>
      </div>
    )
  }

  const { stats, revenueChart, recentOrders, recentRecharges, topProducts } = data || {}

  const statCards = [
    { label: 'Tổng Người Dùng', value: stats?.totalUsers?.toLocaleString(), icon: <Users size={20} />, color: 'text-neon-cyan', bg: 'bg-neon-cyan/10' },
    { label: 'Tổng Đơn Hàng', value: stats?.totalOrders?.toLocaleString(), icon: <ShoppingBag size={20} />, color: 'text-neon-purple', bg: 'bg-neon-purple/10' },
    { label: 'Doanh Thu Tháng', value: formatCurrency(stats?.monthRevenue || 0), icon: <TrendingUp size={20} />, color: 'text-neon-gold', bg: 'bg-neon-gold/10' },
    { label: 'Tổng Doanh Thu', value: formatCurrency(stats?.totalRevenue || 0), icon: <Wallet size={20} />, color: 'text-neon-green', bg: 'bg-neon-green/10' },
  ]

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl text-white uppercase tracking-wider">
          Dashboard
        </h1>
        <p className="text-white/40 text-sm mt-1">Tổng quan hệ thống GameShop VN</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <div key={s.label} className="glass-card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl ${s.bg} ${s.color} flex items-center justify-center`}>
                {s.icon}
              </div>
              <div className="text-xs text-white/30 text-right">
                <div>Hôm nay</div>
                <div className={`font-bold ${s.color}`}>
                  {s.label.includes('Doanh') ? formatCurrency(stats?.todayRevenue || 0) : stats?.todayOrders}
                </div>
              </div>
            </div>
            <div className={`font-display font-black text-xl ${s.color}`}>{s.value}</div>
            <div className="text-xs text-white/50 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Revenue Chart */}
      <div className="glass-card p-6">
        <h2 className="font-display font-bold text-white mb-4 uppercase tracking-wider text-sm flex items-center gap-2">
          <TrendingUp size={16} className="text-neon-cyan" /> Doanh Thu 7 Ngày Gần Đây
        </h2>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={revenueChart}>
            <defs>
              <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00F5FF" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#00F5FF" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => v >= 1000000 ? `${v / 1000000}M` : `${v / 1000}K`}
            />
            <Tooltip
              contentStyle={{ background: '#0F0F1E', border: '1px solid rgba(0,245,255,0.2)', borderRadius: 8 }}
              labelStyle={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Rajdhani' }}
              formatter={(v: any) => [formatCurrency(v), 'Doanh Thu']}
            />
            <Area type="monotone" dataKey="revenue" stroke="#00F5FF" strokeWidth={2} fill="url(#revenueGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2 glass-card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/5 flex items-center gap-2">
            <ShoppingBag size={15} className="text-neon-cyan" />
            <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
              Đơn Hàng Gần Đây
            </h3>
          </div>
          <div className="divide-y divide-white/5">
            {recentOrders?.slice(0, 7).map((order: any) => (
              <div key={order.id} className="px-5 py-3 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold text-white truncate">
                    {order.items[0]?.product?.name || 'Unknown'}
                  </div>
                  <div className="text-xs text-white/40">
                    {order.user?.username} · {formatDate(order.createdAt)}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="price-tag text-sm">{formatCurrency(order.total)}</div>
                  <div className="text-xs text-neon-green">Hoàn thành</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Products */}
        <div className="glass-card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/5 flex items-center gap-2">
            <Star size={15} className="text-neon-gold" />
            <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
              Top Sản Phẩm
            </h3>
          </div>
          <div className="p-4 space-y-3">
            {topProducts?.map((p: any, i: number) => (
              <div key={p.id} className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                  i === 0 ? 'bg-neon-gold text-dark-900' :
                  i === 1 ? 'bg-gray-300 text-dark-900' :
                  i === 2 ? 'bg-orange-400 text-dark-900' :
                  'bg-dark-500 text-white/60'
                }`}>{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-white truncate">{p.name}</div>
                  <div className="text-[10px] text-white/40">Đã bán: {p.sold} · Còn: {p.stock}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
