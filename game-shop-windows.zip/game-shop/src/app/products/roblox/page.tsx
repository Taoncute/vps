// src/app/products/roblox/page.tsx
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'
import { ProductCard } from '@/components/ProductCard'
import { prisma } from '@/lib/prisma'

interface Props {
  searchParams: { cat?: string; sort?: string; page?: string }
}

const categories = [
  { value: '', label: 'Tất Cả' },
  { value: 'account', label: '👤 Tài Khoản' },
  { value: 'robux', label: '💎 Robux' },
  { value: 'service', label: '⚙️ Dịch Vụ' },
]

export default async function RobloxPage({ searchParams }: Props) {
  const { cat = '', sort = 'featured', page = '1' } = searchParams
  const skip = (Number(page) - 1) * 12

  const where: any = { isActive: true, game: 'ROBLOX' }
  if (cat) where.category = cat

  const orderBy: any =
    sort === 'price-asc' ? { price: 'asc' }
    : sort === 'price-desc' ? { price: 'desc' }
    : sort === 'newest' ? { createdAt: 'desc' }
    : { isFeatured: 'desc' }

  const [products, total] = await Promise.all([
    prisma.product.findMany({ where, orderBy, skip, take: 12 }),
    prisma.product.count({ where }),
  ])

  const totalPages = Math.ceil(total / 12)

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Header */}
        <div className="relative bg-gradient-roblox/20 border-b border-white/5 py-10 overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-30" />
          <div className="container mx-auto px-4 relative z-10">
            <div className="flex items-center gap-3 mb-2">
              <span className="badge-roblox text-sm px-3 py-1">ROBLOX</span>
            </div>
            <h1 className="font-display font-black text-4xl md:text-5xl text-white uppercase tracking-wider">
              Shop Roblox
            </h1>
            <p className="text-white/60 mt-2">
              Blox Fruits · Robux · Dịch Vụ Cày Thuê — Uy tín, tự động 24/7
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => (
                <a
                  key={c.value}
                  href={`/products/roblox${c.value ? `?cat=${c.value}` : ''}`}
                  className={`px-4 py-1.5 rounded-full text-sm font-semibold border transition-all ${
                    cat === c.value
                      ? 'bg-neon-cyan text-dark-900 border-neon-cyan'
                      : 'border-white/15 text-white/60 hover:border-neon-cyan/50 hover:text-neon-cyan'
                  }`}
                >
                  {c.label}
                </a>
              ))}
            </div>

            <div className="ml-auto">
              <select
                defaultValue={sort}
                onChange={(e) => {
                  const url = new URL(window.location.href)
                  url.searchParams.set('sort', e.target.value)
                  window.location.href = url.toString()
                }}
                className="bg-dark-600 border border-white/10 text-sm text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-neon-cyan/50"
              >
                <option value="featured">Nổi bật</option>
                <option value="newest">Mới nhất</option>
                <option value="price-asc">Giá tăng dần</option>
                <option value="price-desc">Giá giảm dần</option>
              </select>
            </div>
          </div>

          {/* Stats */}
          <div className="text-xs text-white/40 mb-4">
            Tìm thấy <span className="text-neon-cyan font-bold">{total}</span> sản phẩm
          </div>

          {/* Grid */}
          {products.length === 0 ? (
            <div className="text-center py-24 text-white/30">
              <div className="text-5xl mb-4">🎮</div>
              <div className="font-display text-lg uppercase tracking-wider">Không có sản phẩm</div>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {products.map((p) => (
                <ProductCard key={p.id} product={p as any} />
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-10">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <a
                  key={p}
                  href={`/products/roblox?${new URLSearchParams({ ...(cat && { cat }), sort, page: String(p) })}`}
                  className={`w-9 h-9 flex items-center justify-center rounded-lg text-sm font-bold transition-all ${
                    Number(page) === p
                      ? 'bg-neon-cyan text-dark-900'
                      : 'glass-card text-white/60 hover:text-neon-cyan'
                  }`}
                >
                  {p}
                </a>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
