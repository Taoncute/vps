// src/app/products/genshin/[id]/page.tsx
import { prisma } from '@/lib/prisma'
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'
import { ProductDetail } from '@/components/ProductDetail'
import { notFound } from 'next/navigation'

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id, isActive: true },
  })

  if (!product || product.game !== 'GENSHIN') notFound()

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <ProductDetail product={product as any} />
      </main>
      <Footer />
    </div>
  )
}
