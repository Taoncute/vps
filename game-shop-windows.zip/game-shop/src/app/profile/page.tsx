// src/app/profile/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'
import { formatCurrency, formatDate } from '@/lib/utils'
import { Loader2, User, ShoppingBag, CreditCard, ArrowUpDown } from 'lucide-react'

export default function ProfilePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [tab, setTab] = useState(searchParams.get('tab') || 'orders')
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login?redirect=/profile')
  }, [status])

  useEffect(() => {
    if (!session) return
    fetchProfile()
  }, [session, tab])

  const fetchProfile = async () => {
    setLoading(true)
    const res = await fetch(`/api/user/profile?tab=${tab}`)
    const d = await res.json()
    setData(d)
    setLoading(false)
  }

  if (status === 'loading') {
    return <div className="min-h-screen flex items-center justify-center bg-dark-900"><Loader2 size={32} className="animate-spin text-neon-cyan" /></div>
  }

  const tabs = [
    { key: 'orders', label: 'Đơn Hàng', icon: <ShoppingBag size={15} /> },
    { key: 'recharge', label: 'Nạp Tiền', icon: <CreditCard size={15} /> },
    { key: 'transactions', label: 'Giao Dịch', icon: <ArrowUpDown size={15} /> },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 py-10">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Profile header */}
          <div className="glass-card p-6 mb-6 flex items-center gap-5">
            <div className="w-16 h-16 rounded-full bg-gradient-neon flex items-center justify-center flex-shrink-0">
              <User size={28} className="text-dark-900" />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="font-display font-black text-2xl text-white uppercase tracking-wider">{session?.user.name}</h1>
              <p className="text-white/50 text-sm mt-0.5">{session?.user.email}</p>
            </div>
            <div className="text-right hidden md:block">
              <div className="text-xs text-white/40 mb-1">Số Dư</div>
              <div className="price-tag text-2xl">{formatCurrency(data?.balance ?? 0)}</div>
            </div>
          </div>

          {/* Stats */}
          {data && (
            <div className="grid grid-cols-3 gap-3 mb-6">
              {[
                { label: 'Tổng Nạp', value: formatCurrency(data.totalRecharge || 0), color: 'text-neon-green' },
                { label: 'Tổng Chi', value: formatCurrency(data.totalSpent || 0), color: 'text-neon-cyan' },
                { label: 'Đơn Hàng', value: data.orderCount || 0, color: 'text-neon-purple' },
              ].map(s => (
                <div key={s.label} className="glass-card p-4 text-center">
                  <div className={`font-display font-black text-lg ${s.color}`}>{s.value}</div>
                  <div className="text-xs text-white/40 mt-1 uppercase tracking-wider">{s.label}</div>
                </div>
              ))}
            </div>
          )}

          {/* Tabs */}
          <div className="flex rounded-xl overflow-hidden border border-white/10 mb-6">
            {tabs.map(t => (
              <button key={t.key} onClick={() => setTab(t.key)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-display font-bold uppercase tracking-wider transition-all ${tab === t.key ? 'bg-gradient-neon text-dark-900' : 'bg-dark-700 text-white/60 hover:text-white'}`}>
                {t.icon}{t.label}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="text-center py-16"><Loader2 size={28} className="animate-spin mx-auto text-neon-cyan" /></div>
          ) : (
            <div className="glass-card overflow-hidden">
              {tab === 'orders' && (
                <div>
                  {(!data?.orders || data.orders.length === 0) ? (
                    <div className="py-16 text-center text-white/30">
                      <ShoppingBag size={40} className="mx-auto mb-3 opacity-50" />
                      <div className="font-display uppercase tracking-wider">Chưa có đơn hàng</div>
                    </div>
                  ) : data.orders.map((order: any) => (
                    <div key={order.id} className="px-5 py-4 border-b border-white/5 last:border-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="font-mono text-xs text-white/40 mb-1">{order.id}</div>
                          {order.items.map((item: any) => (
                            <div key={item.id} className="font-bold text-white text-sm">{item.product.name} x{item.quantity}</div>
                          ))}
                          {order.accounts?.length > 0 && (
                            <div className="mt-2 space-y-1">
                              {order.accounts.map((acc: any) => (
                                <div key={acc.id} className="bg-dark-600 rounded p-2 text-xs font-mono">
                                  <span className="text-neon-cyan">User:</span> {acc.username} |{' '}
                                  <span className="text-neon-gold">Pass:</span> {acc.password}
                                </div>
                              ))}
                            </div>
                          )}
                          <div className="text-xs text-white/40 mt-2">{formatDate(order.createdAt)}</div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="price-tag text-base">{formatCurrency(order.total)}</div>
                          <div className={`text-xs font-bold mt-1 ${order.status === 'COMPLETED' ? 'text-green-400' : 'text-yellow-400'}`}>{order.status}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {tab === 'recharge' && (
                <div>
                  {(!data?.recharges || data.recharges.length === 0) ? (
                    <div className="py-16 text-center text-white/30">
                      <CreditCard size={40} className="mx-auto mb-3 opacity-50" />
                      <div className="font-display uppercase tracking-wider">Chưa có lịch sử nạp</div>
                    </div>
                  ) : data.recharges.map((r: any) => (
                    <div key={r.id} className="px-5 py-4 border-b border-white/5 last:border-0 flex items-center justify-between gap-3">
                      <div>
                        <div className="font-bold text-white text-sm">
                          {r.method === 'CARD' ? `Thẻ ${r.cardType}` : 'Chuyển Khoản'}
                        </div>
                        {r.cardSerial && <div className="text-xs text-white/40">Serial: {r.cardSerial}</div>}
                        <div className="text-xs text-white/40">{formatDate(r.createdAt)}</div>
                      </div>
                      <div className="text-right">
                        <div className="price-tag text-base">{formatCurrency(r.amount)}</div>
                        <div className={`text-xs font-bold mt-1 ${r.status === 'SUCCESS' ? 'text-green-400' : r.status === 'PENDING' ? 'text-yellow-400' : 'text-red-400'}`}>
                          {r.status === 'SUCCESS' ? '✓ Thành Công' : r.status === 'PENDING' ? '⏳ Đang Xử Lý' : '✗ Thất Bại'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {tab === 'transactions' && (
                <div>
                  {(!data?.transactions || data.transactions.length === 0) ? (
                    <div className="py-16 text-center text-white/30">
                      <ArrowUpDown size={40} className="mx-auto mb-3 opacity-50" />
                      <div className="font-display uppercase tracking-wider">Chưa có giao dịch</div>
                    </div>
                  ) : data.transactions.map((t: any) => (
                    <div key={t.id} className="px-5 py-3 border-b border-white/5 last:border-0 flex items-center justify-between gap-3">
                      <div>
                        <div className="font-semibold text-white text-sm">{t.note || t.type}</div>
                        <div className="text-xs text-white/40">{formatDate(t.createdAt)}</div>
                      </div>
                      <div className="text-right">
                        <div className={`font-mono font-bold text-sm ${t.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {t.amount > 0 ? '+' : ''}{formatCurrency(t.amount)}
                        </div>
                        <div className="text-xs text-white/40 font-mono">{formatCurrency(t.balance)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
