// src/app/api/products/purchase/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { apiLimiter } from '@/lib/rateLimit'
import { sendTelegram, buildOrderNotification } from '@/lib/telegram'
import { z } from 'zod'
import { nanoid } from 'nanoid'

const schema = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().min(1).max(10),
  promoCode: z.string().optional(),
})

const PROMO_CODE = 'HE2026'
const PROMO_PERCENT = 10

export async function POST(req: NextRequest) {
  const limited = await apiLimiter(req)
  if (limited) return limited

  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Vui lòng đăng nhập' }, { status: 401 })

  try {
    const body = await req.json()
    const { productId, quantity, promoCode } = schema.parse(body)

    const product = await prisma.product.findUnique({ where: { id: productId, isActive: true } })
    if (!product) return NextResponse.json({ error: 'Sản phẩm không tồn tại' }, { status: 404 })
    if (product.stock < quantity) return NextResponse.json({ error: 'Không đủ hàng trong kho' }, { status: 400 })

    let unitPrice = product.price
    let discountApplied = false
    if (promoCode?.toUpperCase() === PROMO_CODE) {
      unitPrice = Math.floor(unitPrice * (1 - PROMO_PERCENT / 100))
      discountApplied = true
    }
    const total = unitPrice * quantity

    const user = await prisma.user.findUnique({ where: { id: session.user.id } })
    if (!user) return NextResponse.json({ error: 'User không tồn tại' }, { status: 404 })
    if (user.balance < total) {
      return NextResponse.json(
        { error: `Số dư không đủ. Cần thêm ${(total - user.balance).toLocaleString()}đ` },
        { status: 400 }
      )
    }

    let reservedAccounts: any[] = []
    if (product.category === 'account') {
      reservedAccounts = await prisma.account.findMany({
        where: { productId, status: 'AVAILABLE' },
        take: quantity,
      })
      if (reservedAccounts.length < quantity) {
        return NextResponse.json({ error: 'Không đủ tài khoản trong kho' }, { status: 400 })
      }
    }

    const orderId = `ORD${nanoid(10).toUpperCase()}`

    const [order, updatedUser] = await prisma.$transaction(async (tx) => {
      const order = await tx.order.create({
        data: {
          id: orderId,
          userId: session.user.id,
          total,
          status: 'COMPLETED',
          note: discountApplied ? `Mã giảm giá: ${promoCode}` : undefined,
          items: { create: { productId, quantity, price: unitPrice } },
        },
      })

      const updUser = await tx.user.update({
        where: { id: session.user.id },
        data: { balance: { decrement: total }, totalSpent: { increment: total } },
      })

      await tx.product.update({
        where: { id: productId },
        data: { stock: { decrement: quantity }, sold: { increment: quantity } },
      })

      if (reservedAccounts.length > 0) {
        await tx.account.updateMany({
          where: { id: { in: reservedAccounts.map((a) => a.id) } },
          data: { status: 'SOLD', orderId, soldAt: new Date() },
        })
      }

      await tx.transaction.create({
        data: {
          userId: session.user.id,
          type: 'PURCHASE',
          amount: -total,
          balance: updUser.balance,
          note: `Mua: ${product.name} x${quantity}`,
          refId: orderId,
        },
      })

      return [order, updUser]
    })

    await sendTelegram(
      buildOrderNotification({
        orderId: order.id,
        username: user.username,
        product: `${product.name} x${quantity}`,
        amount: total,
        balance: updatedUser.balance,
      })
    )

    return NextResponse.json({
      success: true,
      orderId: order.id,
      accounts: reservedAccounts.map((a) => ({
        username: a.username,
        password: a.password,
        email: a.email,
        info: a.info,
      })),
      newBalance: updatedUser.balance,
      discountApplied,
    })
  } catch (e: any) {
    if (e.name === 'ZodError') return NextResponse.json({ error: 'Dữ liệu không hợp lệ' }, { status: 400 })
    console.error('[Purchase]', e)
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}
