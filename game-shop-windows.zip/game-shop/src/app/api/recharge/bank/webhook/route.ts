// src/app/api/recharge/bank/webhook/route.ts
/**
 * SePay / VNPay / custom webhook endpoint
 * SePay sends POST with JSON payload when a bank transfer is detected
 * Configure webhook URL at: https://sepay.vn -> Settings -> Webhook
 * URL: https://yourdomain.com/api/recharge/bank/webhook
 */
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { sendTelegram, buildRechargeNotification } from '@/lib/telegram'
import crypto from 'crypto'

function verifyWebhookSignature(payload: string, signature: string): boolean {
  const secret = process.env.BANK_WEBHOOK_SECRET || ''
  if (!secret) return true // skip verification in dev
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex')
  return expected === signature
}

export async function POST(req: NextRequest) {
  const rawBody = await req.text()
  const signature = req.headers.get('x-sepay-signature') || ''

  if (!verifyWebhookSignature(rawBody, signature)) {
    console.warn('[BankWebhook] Invalid signature')
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
  }

  let data: any
  try {
    data = JSON.parse(rawBody)
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  // SePay payload structure (adjust per provider):
  // { id, gateway, transactionDate, accountNumber, code, content, transferAmount, description, referenceCode, ... }
  const {
    transferAmount,
    content,          // transfer note/description
    referenceCode,    // bank transaction reference
    accountNumber,
    id: webhookId,
  } = data

  if (!transferAmount || transferAmount <= 0) {
    return NextResponse.json({ message: 'ignored' })
  }

  // Extract user code from transfer note (format: NAPTIEN XXXXXX)
  const match = content?.match(/NAPTIEN\s+([A-Z0-9]{6})/i)
  if (!match) {
    console.log('[BankWebhook] No user code in transfer note:', content)
    return NextResponse.json({ message: 'no_match' })
  }

  const userCode = match[1].toUpperCase()

  // Find user by their code (first 6 chars of ID)
  const users = await prisma.user.findMany({
    where: { isActive: true },
    select: { id: true, username: true, balance: true },
  })
  const user = users.find((u) => u.id.substring(0, 6).toUpperCase() === userCode)

  if (!user) {
    console.log('[BankWebhook] User not found for code:', userCode)
    await sendTelegram(
      `⚠️ <b>CHUYỂN KHOẢN KHÔNG XÁC ĐỊNH</b>\n💰 ${transferAmount.toLocaleString()}đ\n📝 Nội dung: ${content}\n🏦 Ref: ${referenceCode}`
    )
    return NextResponse.json({ message: 'user_not_found' })
  }

  // Check duplicate webhook (idempotency)
  const existing = await prisma.recharge.findFirst({
    where: { transferRef: referenceCode },
  })
  if (existing) {
    return NextResponse.json({ message: 'duplicate' })
  }

  // Credit the account (no fee for bank transfer)
  const creditAmount = Number(transferAmount)

  const [recharge, updatedUser] = await prisma.$transaction([
    prisma.recharge.create({
      data: {
        userId: user.id,
        method: 'BANK_TRANSFER',
        amount: creditAmount,
        rawAmount: creditAmount,
        status: 'SUCCESS',
        bankCode: accountNumber,
        transferRef: referenceCode,
        transferNote: content,
        fee: 0,
      },
    }),
    prisma.user.update({
      where: { id: user.id },
      data: {
        balance: { increment: creditAmount },
        totalRecharge: { increment: creditAmount },
      },
    }),
    prisma.transaction.create({
      data: {
        userId: user.id,
        type: 'RECHARGE',
        amount: creditAmount,
        balance: user.balance + creditAmount,
        note: `Chuyển khoản ngân hàng - ${creditAmount.toLocaleString()}đ`,
        refId: referenceCode,
      },
    }),
  ])

  await sendTelegram(
    buildRechargeNotification({
      username: user.username,
      method: 'BANK_TRANSFER',
      amount: creditAmount,
      rawAmount: creditAmount,
      userId: user.id,
    })
  )

  console.log(`[BankWebhook] Credited ${creditAmount} to user ${user.username}`)
  return NextResponse.json({ success: true })
}
