// src/app/api/recharge/card/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { rechargeLimiter } from '@/lib/rateLimit'
import { getSettings } from '@/lib/utils'
import { sendTelegram, buildRechargeNotification } from '@/lib/telegram'
import { z } from 'zod'

const schema = z.object({
  cardType: z.enum(['VIETTEL', 'MOBI', 'VINA', 'VIETNAMOBILE', 'GMOBILE']),
  cardSerial: z.string().min(10).max(20).regex(/^\d+$/),
  cardCode: z.string().min(10).max(20).regex(/^\d+$/),
  cardValue: z.number().int().positive(),
})

const CARD_API = process.env.CARD_API_ENDPOINT || 'https://thesieure.com/chargingws/v2'
const FEE_PERCENT = 20

export async function POST(req: NextRequest) {
  const limited = await rechargeLimiter(req)
  if (limited) return limited

  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Vui lòng đăng nhập' }, { status: 401 })

  try {
    const body = await req.json()
    const { cardType, cardSerial, cardCode, cardValue } = schema.parse(body)

    const settings = await getSettings(['CARD_API_PARTNER_ID', 'CARD_API_PARTNER_KEY'])
    const partnerId = settings.CARD_API_PARTNER_ID || process.env.CARD_API_PARTNER_ID
    const partnerKey = settings.CARD_API_PARTNER_KEY || process.env.CARD_API_PARTNER_KEY

    if (!partnerId || !partnerKey) {
      return NextResponse.json({ error: 'Hệ thống nạp thẻ đang bảo trì' }, { status: 503 })
    }

    // Create pending recharge record
    const recharge = await prisma.recharge.create({
      data: {
        userId: session.user.id,
        method: 'CARD',
        amount: Math.floor(cardValue * (1 - FEE_PERCENT / 100)),
        rawAmount: cardValue,
        status: 'PENDING',
        cardType,
        cardSerial,
        cardCode,
        fee: Math.floor(cardValue * FEE_PERCENT / 100),
      },
    })

    // Call thesieure/gachthe247 API
    const requestId = recharge.id
    const sign = require('crypto')
      .createHash('md5')
      .update(`${partnerKey}${partnerId}${cardCode}${cardSerial}`)
      .digest('hex')

    const apiRes = await fetch(CARD_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        partnercode: partnerId,
        partnerkey: partnerKey,
        requestid: requestId,
        telco: cardType,
        code: cardCode,
        serial: cardSerial,
        amount: cardValue,
        sign,
      }),
    })

    const apiData = await apiRes.json()

    // status 1 = success, 2 = pending (processing), 3 = error
    if (apiData.status === 3) {
      await prisma.recharge.update({
        where: { id: recharge.id },
        data: { status: 'FAILED' },
      })
      return NextResponse.json({ error: apiData.message || 'Thẻ không hợp lệ' }, { status: 400 })
    }

    if (apiData.status === 1) {
      // Immediate success
      const creditAmount = Math.floor(apiData.amount * (1 - FEE_PERCENT / 100))
      await prisma.$transaction([
        prisma.recharge.update({
          where: { id: recharge.id },
          data: { status: 'SUCCESS', amount: creditAmount },
        }),
        prisma.user.update({
          where: { id: session.user.id },
          data: {
            balance: { increment: creditAmount },
            totalRecharge: { increment: creditAmount },
          },
        }),
        prisma.transaction.create({
          data: {
            userId: session.user.id,
            type: 'RECHARGE',
            amount: creditAmount,
            balance: 0, // will recalculate
            note: `Nạp thẻ ${cardType} - ${cardValue.toLocaleString()}đ`,
            refId: recharge.id,
          },
        }),
      ])

      const user = await prisma.user.findUnique({
        where: { id: session.user.id },
        select: { username: true },
      })
      await sendTelegram(
        buildRechargeNotification({
          username: user?.username || 'Unknown',
          method: 'CARD',
          amount: creditAmount,
          rawAmount: cardValue,
          userId: session.user.id,
        })
      )
    }

    // status 2 = pending, webhook will handle it
    return NextResponse.json({
      success: true,
      status: apiData.status,
      message: apiData.status === 1
        ? 'Nạp thẻ thành công!'
        : 'Thẻ đang được xử lý, vui lòng chờ 1-3 phút.',
    })
  } catch (e: any) {
    if (e.name === 'ZodError') {
      return NextResponse.json({ error: 'Thông tin thẻ không hợp lệ' }, { status: 400 })
    }
    console.error('[CardRecharge]', e)
    return NextResponse.json({ error: 'Lỗi hệ thống, vui lòng thử lại' }, { status: 500 })
  }
}
