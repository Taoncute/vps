// src/app/api/admin/users/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { sendTelegram } from '@/lib/telegram'
import { z } from 'zod'

async function requireAdmin(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'ADMIN') return null
  return session
}

export async function GET(req: NextRequest) {
  const session = await requireAdmin(req)
  if (!session) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { searchParams } = new URL(req.url)
  const page = Number(searchParams.get('page') || 1)
  const search = searchParams.get('q') || ''
  const take = 20
  const skip = (page - 1) * take

  const where: any = search
    ? { OR: [{ username: { contains: search, mode: 'insensitive' } }, { email: { contains: search, mode: 'insensitive' } }] }
    : {}

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where, skip, take,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, username: true, email: true, balance: true,
        totalSpent: true, totalRecharge: true, role: true,
        isActive: true, createdAt: true,
        _count: { select: { orders: true } },
      },
    }),
    prisma.user.count({ where }),
  ])

  return NextResponse.json({ users, total, pages: Math.ceil(total / take) })
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin(req)
  if (!session) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const schema = z.object({
    userId: z.string(),
    amount: z.number(),
    note: z.string().optional(),
  })

  try {
    const { userId, amount, note } = schema.parse(await req.json())
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user) return NextResponse.json({ error: 'User không tồn tại' }, { status: 404 })

    const newBalance = user.balance + amount
    if (newBalance < 0) return NextResponse.json({ error: 'Số dư không được âm' }, { status: 400 })

    await prisma.$transaction([
      prisma.user.update({ where: { id: userId }, data: { balance: { increment: amount } } }),
      prisma.transaction.create({
        data: {
          userId, type: amount > 0 ? 'ADMIN_ADD' : 'ADMIN_SUB',
          amount, balance: newBalance,
          note: note || `Admin điều chỉnh: ${amount > 0 ? '+' : ''}${amount.toLocaleString()}đ`,
        },
      }),
    ])

    await sendTelegram(
      `👤 <b>ADMIN ĐIỀU CHỈNH SỐ DƯ</b>\nUser: <b>${user.username}</b>\n` +
      `Điều chỉnh: <b>${amount > 0 ? '+' : ''}${amount.toLocaleString()}đ</b>\nSố dư mới: ${newBalance.toLocaleString()}đ`
    )

    return NextResponse.json({ success: true, newBalance })
  } catch (e: any) {
    if (e.name === 'ZodError') return NextResponse.json({ error: e.errors[0]?.message }, { status: 400 })
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}
