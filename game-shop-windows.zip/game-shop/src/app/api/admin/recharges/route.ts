// src/app/api/admin/recharges/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { searchParams } = new URL(req.url)
  const page = Number(searchParams.get('page') || 1)
  const status = searchParams.get('status') || undefined
  const where: any = {}
  if (status) where.status = status

  const [recharges, total] = await Promise.all([
    prisma.recharge.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * 20,
      take: 20,
      include: { user: { select: { username: true, email: true } } },
    }),
    prisma.recharge.count({ where }),
  ])

  return NextResponse.json({ recharges, total })
}
