// src/app/api/admin/accounts/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

async function isAdmin(req: NextRequest) {
  const session = await getServerSession(authOptions)
  return session?.user.role === 'ADMIN'
}

// GET: list accounts for a product
export async function GET(req: NextRequest) {
  if (!(await isAdmin(req))) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { searchParams } = new URL(req.url)
  const productId = searchParams.get('productId')
  const status = searchParams.get('status') || undefined
  const page = Number(searchParams.get('page') || 1)
  const where: any = {}
  if (productId) where.productId = productId
  if (status) where.status = status

  const [accounts, total] = await Promise.all([
    prisma.account.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * 50, take: 50 }),
    prisma.account.count({ where }),
  ])
  return NextResponse.json({ accounts, total })
}

// POST: bulk import accounts (newline-separated "user|pass" or "user|pass|email|emailpass")
export async function POST(req: NextRequest) {
  if (!(await isAdmin(req))) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { productId, raw } = await req.json()
  if (!productId || !raw) return NextResponse.json({ error: 'Missing productId or raw data' }, { status: 400 })

  const product = await prisma.product.findUnique({ where: { id: productId } })
  if (!product) return NextResponse.json({ error: 'Product not found' }, { status: 404 })

  const lines = (raw as string)
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)

  const accounts = lines.map((line) => {
    const parts = line.split('|')
    return {
      productId,
      username: parts[0] || '',
      password: parts[1] || '',
      email: parts[2] || null,
      emailPass: parts[3] || null,
    }
  }).filter((a) => a.username && a.password)

  if (!accounts.length) return NextResponse.json({ error: 'Không có tài khoản hợp lệ' }, { status: 400 })

  const result = await prisma.account.createMany({ data: accounts, skipDuplicates: true })

  // Update product stock
  await prisma.product.update({
    where: { id: productId },
    data: { stock: { increment: result.count } },
  })

  return NextResponse.json({ imported: result.count })
}

export async function DELETE(req: NextRequest) {
  if (!(await isAdmin(req))) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 })

  const account = await prisma.account.findUnique({ where: { id } })
  if (!account) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (account.status === 'SOLD') return NextResponse.json({ error: 'Không thể xóa tài khoản đã bán' }, { status: 400 })

  await prisma.$transaction([
    prisma.account.delete({ where: { id } }),
    prisma.product.update({ where: { id: account.productId }, data: { stock: { decrement: 1 } } }),
  ])

  return NextResponse.json({ success: true })
}
