// src/app/api/admin/stats/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const now = new Date()
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)

  const [
    totalUsers, totalOrders, totalProducts,
    todayOrders, monthOrders, pendingOrders,
    recentOrders, recentRecharges,
    revenueToday, revenueMonth,
    topProducts, lowStock,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.order.count(),
    prisma.product.count({ where: { isActive: true } }),
    prisma.order.count({ where: { createdAt: { gte: todayStart } } }),
    prisma.order.count({ where: { createdAt: { gte: monthStart } } }),
    prisma.order.count({ where: { status: 'PENDING' } }),
    prisma.order.findMany({
      orderBy: { createdAt: 'desc' }, take: 10,
      include: {
        user: { select: { username: true } },
        items: { include: { product: { select: { name: true } } } },
      },
    }),
    prisma.recharge.findMany({
      orderBy: { createdAt: 'desc' }, take: 10,
      include: { user: { select: { username: true } } },
    }),
    prisma.order.aggregate({
      where: { status: 'COMPLETED', createdAt: { gte: todayStart } },
      _sum: { total: true },
    }),
    prisma.order.aggregate({
      where: { status: 'COMPLETED', createdAt: { gte: monthStart } },
      _sum: { total: true },
    }),
    prisma.product.findMany({
      orderBy: { sold: 'desc' }, take: 5,
      select: { id: true, name: true, sold: true, stock: true, price: true, game: true },
    }),
    prisma.product.findMany({
      where: { stock: { lte: 5 }, isActive: true },
      orderBy: { stock: 'asc' }, take: 5,
      select: { id: true, name: true, stock: true, game: true },
    }),
  ])

  return NextResponse.json({
    users: { total: totalUsers },
    orders: { total: totalOrders, today: todayOrders, month: monthOrders, pending: pendingOrders },
    products: { total: totalProducts, lowStock },
    revenue: { today: revenueToday._sum.total ?? 0, month: revenueMonth._sum.total ?? 0 },
    recentOrders, recentRecharges, topProducts,
  })
}
