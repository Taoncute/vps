// src/app/api/user/profile/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const tab = searchParams.get('tab') || 'orders'

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: {
      balance: true, totalSpent: true, totalRecharge: true,
      _count: { select: { orders: true } },
    },
  })

  let tabData: any = {}

  if (tab === 'orders') {
    tabData.orders = await prisma.order.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        items: { include: { product: { select: { name: true } } } },
        accounts: { where: { status: 'SOLD' }, select: { id: true, username: true, password: true, email: true, info: true } },
      },
    })
  } else if (tab === 'recharge') {
    tabData.recharges = await prisma.recharge.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
      take: 30,
    })
  } else if (tab === 'transactions') {
    tabData.transactions = await prisma.transaction.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })
  }

  return NextResponse.json({
    balance: user?.balance ?? 0,
    totalSpent: user?.totalSpent ?? 0,
    totalRecharge: user?.totalRecharge ?? 0,
    orderCount: user?._count.orders ?? 0,
    ...tabData,
  })
}
