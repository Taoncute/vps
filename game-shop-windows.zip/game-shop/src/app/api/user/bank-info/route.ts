// src/app/api/user/bank-info/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { getSettings } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const settings = await getSettings([
    'BANK_ACCOUNT', 'BANK_NAME', 'BANK_OWNER', 'BANK_BIN',
  ])

  // Create unique transfer note per user
  const userCode = session.user.id.substring(0, 6).toUpperCase()
  const transferNote = `NAPTIEN ${userCode}`

  return NextResponse.json({
    bankAccount: settings.BANK_ACCOUNT || process.env.BANK_ACCOUNT,
    bankName: settings.BANK_NAME || process.env.BANK_NAME,
    bankOwner: settings.BANK_OWNER || process.env.BANK_OWNER,
    bankBin: settings.BANK_BIN || process.env.BANK_BIN || '546034',
    transferNote,
  })
}
