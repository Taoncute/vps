// src/app/api/auth/register/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { loginLimiter } from '@/lib/rateLimit'
import { z } from 'zod'

const schema = z.object({
  username: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/, 'Chỉ dùng chữ, số và dấu gạch dưới'),
  email: z.string().email('Email không hợp lệ'),
  password: z.string().min(8, 'Mật khẩu phải có ít nhất 8 ký tự'),
})

export async function POST(req: NextRequest) {
  const limited = await loginLimiter(req)
  if (limited) return limited

  try {
    const body = await req.json()
    const { username, email, password } = schema.parse(body)

    const existing = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }] },
    })
    if (existing) {
      return NextResponse.json(
        { error: existing.email === email ? 'Email đã được sử dụng' : 'Tên đăng nhập đã tồn tại' },
        { status: 400 }
      )
    }

    const hashed = await bcrypt.hash(password, 12)
    const user = await prisma.user.create({
      data: { username, email, password: hashed },
      select: { id: true, username: true, email: true },
    })

    return NextResponse.json({ success: true, user }, { status: 201 })
  } catch (e: any) {
    if (e.name === 'ZodError') {
      return NextResponse.json({ error: e.errors[0]?.message || 'Dữ liệu không hợp lệ' }, { status: 400 })
    }
    console.error('[Register]', e)
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}
