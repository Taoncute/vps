// src/app/recharge/page.tsx
'use client'
import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'
import { formatCurrency } from '@/lib/utils'
import toast from 'react-hot-toast'
import { CreditCard, Landmark, Copy, QrCode, CheckCircle, Loader2 } from 'lucide-react'
import QRCode from 'qrcode'

const CARD_TYPES = ['VIETTEL', 'MOBI', 'VINA', 'VIETNAMOBILE', 'GMOBILE']
const CARD_VALUES = [10000, 20000, 30000, 50000, 100000, 200000, 300000, 500000]

const FEE_PERCENT = 20

export default function RechargePage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [tab, setTab] = useState<'card' | 'bank'>('bank')
  const [cardType, setCardType] = useState('VIETTEL')
  const [cardSerial, setCardSerial] = useState('')
  const [cardCode, setCardCode] = useState('')
  const [cardValue, setCardValue] = useState(100000)
  const [loading, setLoading] = useState(false)

  // Bank info
  const [bankInfo, setBankInfo] = useState<any>(null)
  const [transferNote, setTransferNote] = useState('')
  const [qrUrl, setQrUrl] = useState('')
  const [bankAmount, setBankAmount] = useState(100000)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login?redirect=/recharge')
  }, [status])

  useEffect(() => {
    if (!session) return
    fetch('/api/user/bank-info')
      .then((r) => r.json())
      .then(async (data) => {
        setBankInfo(data)
        setTransferNote(data.transferNote)
        // Generate VietQR
        const qrData = `https://img.vietqr.io/image/${data.bankBin}-${data.bankAccount}-compact2.png?amount=${bankAmount}&addInfo=${encodeURIComponent(data.transferNote)}&accountName=${encodeURIComponent(data.bankOwner)}`
        setQrUrl(qrData)
      })
  }, [session])

  useEffect(() => {
    if (!bankInfo) return
    setQrUrl(
      `https://img.vietqr.io/image/${bankInfo.bankBin}-${bankInfo.bankAccount}-compact2.png?amount=${bankAmount}&addInfo=${encodeURIComponent(transferNote)}&accountName=${encodeURIComponent(bankInfo.bankOwner)}`
    )
  }, [bankAmount, bankInfo])

  const handleCardRecharge = async () => {
    if (!cardSerial.trim() || !cardCode.trim()) {
      toast.error('Vui lòng nhập đầy đủ thông tin thẻ')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/recharge/card', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardType, cardSerial, cardCode, cardValue }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Lỗi nạp thẻ')
      toast.success('Thẻ đang được xử lý! Vui lòng chờ 1-3 phút.')
      setCardSerial('')
      setCardCode('')
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => toast.success(`Đã sao chép ${label}`))
  }

  const received = Math.floor(cardValue * (1 - FEE_PERCENT / 100))

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-dark-900">
        <Loader2 size={32} className="animate-spin text-neon-cyan" />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 py-10">
        <div className="container mx-auto px-4 max-w-3xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="section-title text-3xl mb-2">Nạp Tiền</h1>
            <p className="text-white/50 text-sm">Chọn phương thức nạp tiền phù hợp</p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-xl overflow-hidden border border-white/10 mb-6">
            {[
              { key: 'bank', label: '🏦 Chuyển Khoản', icon: <Landmark size={16} /> },
              { key: 'card', label: '🃏 Thẻ Cào', icon: <CreditCard size={16} /> },
            ].map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key as any)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-display font-bold uppercase tracking-wider transition-all ${
                  tab === t.key
                    ? 'bg-gradient-neon text-dark-900'
                    : 'bg-dark-700 text-white/60 hover:text-white'
                }`}
              >
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {/* Bank Transfer */}
          {tab === 'bank' && bankInfo && (
            <div className="glass-card p-6 space-y-6">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-neon-cyan/5 border border-neon-cyan/20">
                <CheckCircle size={18} className="text-neon-cyan flex-shrink-0 mt-0.5" />
                <p className="text-sm text-white/70">
                  Chuyển khoản theo đúng nội dung bên dưới. Hệ thống tự động xác nhận trong{' '}
                  <span className="text-neon-cyan font-bold">30 giây – 2 phút</span>.
                </p>
              </div>

              {/* Amount picker */}
              <div>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                  Số tiền chuyển khoản
                </label>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-2 mb-3">
                  {[50000, 100000, 200000, 500000, 1000000, 2000000].map((v) => (
                    <button
                      key={v}
                      onClick={() => setBankAmount(v)}
                      className={`py-2 rounded-lg text-xs font-bold font-display border transition-all ${
                        bankAmount === v
                          ? 'bg-neon-cyan text-dark-900 border-neon-cyan'
                          : 'border-white/10 text-white/60 hover:border-neon-cyan/40'
                      }`}
                    >
                      {formatCurrency(v)}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  value={bankAmount}
                  onChange={(e) => setBankAmount(Number(e.target.value))}
                  min={10000}
                  step={10000}
                  className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-neon-cyan/50 font-mono"
                  placeholder="Nhập số tiền khác..."
                />
              </div>

              {/* Bank info */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  {[
                    { label: 'Ngân Hàng', value: bankInfo.bankName },
                    { label: 'Số Tài Khoản', value: bankInfo.bankAccount, copy: true },
                    { label: 'Chủ Tài Khoản', value: bankInfo.bankOwner },
                    { label: 'Nội Dung CK', value: transferNote, copy: true, highlight: true },
                  ].map((row) => (
                    <div key={row.label} className={`rounded-lg p-3 ${row.highlight ? 'bg-neon-gold/10 border border-neon-gold/30' : 'bg-dark-600 border border-white/5'}`}>
                      <div className="text-xs text-white/50 mb-1">{row.label}</div>
                      <div className="flex items-center justify-between gap-2">
                        <span className={`font-mono font-bold text-sm ${row.highlight ? 'text-neon-gold' : 'text-white'}`}>
                          {row.value}
                        </span>
                        {row.copy && (
                          <button
                            onClick={() => copyToClipboard(row.value, row.label)}
                            className="text-white/40 hover:text-neon-cyan transition-colors flex-shrink-0"
                          >
                            <Copy size={14} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* QR Code */}
                <div className="flex flex-col items-center gap-3">
                  <div className="text-xs font-bold text-white/50 uppercase tracking-wider flex items-center gap-1">
                    <QrCode size={14} /> VietQR
                  </div>
                  {qrUrl && (
                    <img
                      src={qrUrl}
                      alt="VietQR"
                      className="w-48 h-48 rounded-xl border-2 border-neon-cyan/30 bg-white p-1"
                    />
                  )}
                  <p className="text-xs text-white/40 text-center">
                    Quét mã QR bằng app ngân hàng để chuyển khoản nhanh
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Card Recharge */}
          {tab === 'card' && (
            <div className="glass-card p-6 space-y-5">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-orange-500/10 border border-orange-500/30">
                <span className="text-orange-400 text-lg">⚠️</span>
                <p className="text-sm text-white/70">
                  Thẻ cào bị trừ phí <span className="text-orange-400 font-bold">{FEE_PERCENT}%</span>. 
                  Thẻ sai mệnh giá bị phạt thêm 10%. Vui lòng kiểm tra kỹ trước khi nạp.
                </p>
              </div>

              {/* Card type */}
              <div>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                  Nhà Mạng
                </label>
                <div className="flex flex-wrap gap-2">
                  {CARD_TYPES.map((type) => (
                    <button
                      key={type}
                      onClick={() => setCardType(type)}
                      className={`px-4 py-2 rounded-lg text-sm font-bold font-display border transition-all ${
                        cardType === type
                          ? 'bg-neon-cyan text-dark-900 border-neon-cyan'
                          : 'border-white/10 text-white/60 hover:border-neon-cyan/40'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Card value */}
              <div>
                <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                  Mệnh Giá
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {CARD_VALUES.map((v) => (
                    <button
                      key={v}
                      onClick={() => setCardValue(v)}
                      className={`py-2 rounded-lg text-xs font-bold font-display border transition-all ${
                        cardValue === v
                          ? 'bg-neon-cyan text-dark-900 border-neon-cyan'
                          : 'border-white/10 text-white/60 hover:border-neon-cyan/40'
                      }`}
                    >
                      {v >= 1000000 ? `${v / 1000000}M` : `${v / 1000}K`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Serial & Code */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                    Số Seri
                  </label>
                  <input
                    type="text"
                    value={cardSerial}
                    onChange={(e) => setCardSerial(e.target.value.replace(/\D/g, ''))}
                    placeholder="Nhập số seri thẻ..."
                    className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-neon-cyan/50 font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">
                    Mã Thẻ
                  </label>
                  <input
                    type="text"
                    value={cardCode}
                    onChange={(e) => setCardCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="Nhập mã thẻ..."
                    className="w-full bg-dark-600 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-neon-cyan/50 font-mono"
                  />
                </div>
              </div>

              {/* Summary */}
              <div className="rounded-lg bg-dark-600 border border-white/5 p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-white/50">Mệnh giá thẻ</span>
                  <span className="font-mono text-white">{formatCurrency(cardValue)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/50">Phí xử lý ({FEE_PERCENT}%)</span>
                  <span className="font-mono text-red-400">-{formatCurrency(cardValue * FEE_PERCENT / 100)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold border-t border-white/10 pt-2 mt-2">
                  <span className="text-white/80">Nhận được</span>
                  <span className="price-tag">{formatCurrency(received)}</span>
                </div>
              </div>

              <button
                onClick={handleCardRecharge}
                disabled={loading}
                className="w-full btn-neon py-3 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <CreditCard size={16} />}
                {loading ? 'Đang Xử Lý...' : 'Nạp Thẻ Ngay'}
              </button>
            </div>
          )}

          {/* History shortcut */}
          <div className="mt-6 text-center">
            <a href="/profile?tab=recharge" className="text-sm text-neon-cyan hover:underline">
              Xem lịch sử nạp tiền →
            </a>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
