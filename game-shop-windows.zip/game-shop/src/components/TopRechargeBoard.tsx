// src/components/TopRechargeBoard.tsx
import { formatCurrency } from '@/lib/utils'
import { Trophy, Medal, Award } from 'lucide-react'

interface User {
  username: string
  totalRecharge: number
  avatar?: string | null
}

const rankIcons = [
  <Trophy size={16} className="text-yellow-400" />,
  <Medal size={16} className="text-gray-300" />,
  <Award size={16} className="text-orange-400" />,
]

export function TopRechargeBoard({ users }: { users: User[] }) {
  return (
    <div>
      <h2 className="section-title mb-6">🏆 Bảng Xếp Hạng Nạp</h2>
      <div className="glass-card overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 border-b border-white/5 bg-gradient-to-r from-neon-gold/10 to-transparent flex items-center gap-2">
          <Trophy size={16} className="text-neon-gold" />
          <span className="font-display font-bold text-sm uppercase tracking-wider text-neon-gold">
            Top Người Nạp Nhiều Nhất
          </span>
        </div>

        {users.length === 0 && (
          <div className="py-12 text-center text-white/30 text-sm">
            Chưa có dữ liệu
          </div>
        )}

        <div className="divide-y divide-white/5">
          {users.map((user, i) => (
            <div
              key={user.username}
              className={`flex items-center gap-3 px-4 py-3 hover:bg-white/3 transition-colors ${
                i < 3 ? 'bg-gradient-to-r from-neon-gold/5 to-transparent' : ''
              }`}
            >
              {/* Rank */}
              <div className="w-8 flex-shrink-0 text-center">
                {i < 3 ? (
                  rankIcons[i]
                ) : (
                  <span className="text-white/30 text-sm font-mono font-bold">#{i + 1}</span>
                )}
              </div>

              {/* Avatar */}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-display font-black text-sm flex-shrink-0 ${
                i === 0 ? 'bg-yellow-400 text-dark-900' :
                i === 1 ? 'bg-gray-300 text-dark-900' :
                i === 2 ? 'bg-orange-400 text-dark-900' :
                'bg-dark-600 text-white'
              }`}>
                {user.username[0].toUpperCase()}
              </div>

              {/* Name */}
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm text-white truncate">
                  {user.username.replace(/(.{2}).*(.{2})/, '$1***$2')}
                </div>
              </div>

              {/* Amount */}
              <div className={`text-sm font-mono font-bold flex-shrink-0 ${
                i < 3 ? 'text-neon-gold' : 'text-white/60'
              }`}>
                {formatCurrency(user.totalRecharge)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
