// src/components/Footer.tsx
import Link from 'next/link'
import { Sword, MessageCircle, Mail } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-dark-800 border-t border-white/5 mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-neon rounded-lg flex items-center justify-center">
                <Sword size={16} className="text-dark-900" />
              </div>
              <span className="font-display font-black text-xl">
                <span className="text-neon-cyan">GAME</span>
                <span className="text-white">SHOP</span>
                <span className="text-neon-gold"> VN</span>
              </span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-4">
              Nền tảng mua bán tài khoản game, nạp thẻ uy tín hàng đầu Việt Nam. 
              Giao dịch tự động 24/7, bảo mật cao cấp với Cloudflare Anti-DDoS.
            </p>
            <div className="flex gap-3">
              <a
                href="https://t.me/gameshopvn"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#229ED9]/20 border border-[#229ED9]/30 text-[#229ED9] text-xs font-semibold hover:bg-[#229ED9]/30 transition-colors"
              >
                <MessageCircle size={14} /> Telegram
              </a>
              <a
                href="mailto:support@gameshop.vn"
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-neon-cyan/10 border border-neon-cyan/20 text-neon-cyan text-xs font-semibold hover:bg-neon-cyan/20 transition-colors"
              >
                <Mail size={14} /> Email
              </a>
            </div>
          </div>

          {/* Sản phẩm */}
          <div>
            <h4 className="font-display font-bold text-sm uppercase tracking-wider text-white/80 mb-4">
              Sản Phẩm
            </h4>
            <ul className="space-y-2">
              {[
                { label: 'Acc Blox Fruits', href: '/products/roblox?cat=account' },
                { label: 'Nạp Robux', href: '/products/roblox?cat=robux' },
                { label: 'Acc Genshin', href: '/products/genshin?cat=account' },
                { label: 'Nạp Crystals', href: '/products/genshin?cat=crystal' },
                { label: 'Dịch Vụ Cày', href: '/products/roblox?cat=service' },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-white/50 hover:text-neon-cyan transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Hỗ trợ */}
          <div>
            <h4 className="font-display font-bold text-sm uppercase tracking-wider text-white/80 mb-4">
              Hỗ Trợ
            </h4>
            <ul className="space-y-2">
              {[
                { label: 'Nạp Tiền', href: '/recharge' },
                { label: 'Lịch Sử Giao Dịch', href: '/profile?tab=transactions' },
                { label: 'Điều Khoản', href: '/terms' },
                { label: 'Chính Sách', href: '/privacy' },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-white/50 hover:text-neon-cyan transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>

            <div className="mt-6 p-3 rounded-lg bg-neon-gold/10 border border-neon-gold/20">
              <div className="text-xs font-bold text-neon-gold font-display mb-1">Thanh Toán</div>
              <div className="text-xs text-white/60">
                Thẻ cào · Chuyển khoản · VietQR
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-3">
          <div className="text-xs text-white/30">
            © 2026 GameShop VN. Bảo lưu mọi quyền.
          </div>
          <div className="text-xs text-white/30">
            Được bảo vệ bởi{' '}
            <span className="text-orange-400 font-semibold">Cloudflare</span> &amp; SSL
          </div>
        </div>
      </div>
    </footer>
  )
}
