// src/components/GameSection.tsx
import Link from 'next/link'
import { ProductCard } from './ProductCard'
import { ArrowRight } from 'lucide-react'

interface GameSectionProps {
  game: string
  products: any[]
  title: string
  subtitle: string
  href: string
  accentColor: string
}

export function GameSection({ game, products, title, subtitle, href, accentColor }: GameSectionProps) {
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <h2 className={`font-display font-black text-3xl md:text-4xl uppercase tracking-wider bg-gradient-to-r ${accentColor} bg-clip-text text-transparent`}>
            {title}
          </h2>
          <p className="text-white/50 text-sm mt-1 font-body">{subtitle}</p>
        </div>
        <Link
          href={href}
          className="flex items-center gap-2 text-sm font-semibold text-neon-cyan hover:gap-3 transition-all group"
        >
          Xem tất cả sản phẩm
          <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  )
}
