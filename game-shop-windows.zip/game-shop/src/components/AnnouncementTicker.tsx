// src/components/AnnouncementTicker.tsx
'use client'

interface Announcement {
  id: string
  content: string
  type: string
}

export function AnnouncementTicker({ announcements }: { announcements: Announcement[] }) {
  if (!announcements.length) return null
  const items = [...announcements, ...announcements] // duplicate for seamless loop

  return (
    <div className="bg-dark-700 border-b border-white/5 overflow-hidden">
      <div className="flex items-center">
        <div className="flex-shrink-0 bg-neon-cyan px-3 py-1.5 text-dark-900 font-display font-bold text-xs uppercase tracking-wider">
          TIN TỨC
        </div>
        <div className="flex-1 overflow-hidden">
          <div
            className="flex gap-12 whitespace-nowrap py-1.5 px-4"
            style={{ animation: 'marquee 30s linear infinite' }}
          >
            {items.map((a, i) => (
              <span key={`${a.id}-${i}`} className="text-xs text-white/70 flex-shrink-0">
                {a.content}
              </span>
            ))}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  )
}
