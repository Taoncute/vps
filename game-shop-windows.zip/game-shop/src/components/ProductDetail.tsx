// src/components/ProductDetail.tsx
'use client'
import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { formatCurrency } from '@/lib/utils'
import toast from 'react-hot-toast'
import {
  ShoppingCart, Shield, Zap, Package, Tag, CheckCircle,
  Loader2, ArrowLeft, Copy,
} from 'lucide-react'
import Link from 'next/link'

interface ProductDetailProps {
  product: {
    id: string
    name: string
    description?: string | null
    price: number
    originalPrice?: number | null
    game: string
    category: string
    stock: number
    sold: number
    isFeatured: boolean
    metadata?: any
  }
}

export function ProductDetail({ product }: ProductDetailProps) {
  const { data: session } = useSession()
  const router = useRouter()
  const [quantity, setQuantity] = useState(1)
  const [promoCode, setPromoCode] = useState('')
  const [promoApplied, setPromoApplied] = useState(false)
  const [buying, setBuying] = useState(false)
  const [orderResult, setOrderResult] = useState<any>(null)

  const isRoblox = product.game === 'ROBLOX'
  const discountPct = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100) : null

  const effectivePrice = promoApplied
    ? Math.floor(product.price * 0.9)
    : product.price
  const total = effectivePrice * quantity

  const applyPromo = () => {
    if (promoCode.toUpperCase() === 'HE2026') {
      setPromoApplied(true)
      toast.success('Mã HE2026 áp dụng thành công! Giảm 10%')
    } else {
      toast.error('Mã giảm giá không hợp lệ')
    }
  }

  const handleBuy = async () => {
    if (!session) {
      toast.error('Vui lòng đăng nhập để mua hàng')
      router.push(`/login?redirect=/products/${isRoblox ? 'roblox' : 'genshin'}/${product.id}`)
      return
    }
    if (product.stock === 0) { toast.error('Sản phẩm đã hết hàng'); return }

    setBuying(true)
    try {
      const res = await fetch('/api/products/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          quantity,
          promoCode: promoApplied ? promoCode : undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success('Mua hàng thành công!')
      setOrderResult(data)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setBuying(false)
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => toast.success(`Đã sao chép ${label}`))
  }

  // Success screen
  if (orderResult) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        <div className="glass-card p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-500/20 border border-green-500/40 flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-green-400" />
          </div>
          <h2 className="font-display font-black text-2xl text-white uppercase tracking-wider mb-2">
            Mua Hàng Thành Công!
          </h2>
          <p className="text-white/50 text-sm mb-6">Mã đơn: <span className="font-mono text-neon-cyan">{orderResult.orderId}</span></p>

          {orderResult.accounts?.length > 0 && (
            <div className="space-y-3 mb-6 text-left">
              <div className="text-xs font-bold text-white/50 uppercase tracking-wider">Thông tin tài khoản</div>
              {orderResult.accounts.map((acc: any, i: number) => (
                <div key={i} className="bg-dark-600 border border-neon-cyan/20 rounded-xl p-4 space-y-2">
                  {[
                    { label: 'Username', value: acc.username },
                    { label: 'Password', value: acc.password },
                    ...(acc.email ? [{ label: 'Email', value: acc.email }] : []),
                  ].map(({ label, value }) => (
                    <div key={label} className="flex items-center justify-between gap-3">
                      <div>
                        <div className="text-xs text-white/40">{label}</div>
                        <div className="font-mono font-bold text-neon-cyan text-sm">{value}</div>
                      </div>
                      <button onClick={() => copyToClipboard(value, label)} className="text-white/40 hover:text-neon-cyan">
                        <Copy size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3 mb-6 text-xs text-orange-300 text-left">
            ⚠️ Hãy lưu lại thông tin tài khoản ngay. Chúng tôi không chịu trách nhiệm nếu bạn mất thông tin sau khi rời khỏi trang này.
          </div>

          <div className="flex gap-3">
            <Link href="/profile?tab=orders" className="flex-1 btn-outline-neon py-2.5 text-center">Xem Đơn Hàng</Link>
            <Link href={isRoblox ? '/products/roblox' : '/products/genshin'} className="flex-1 btn-neon py-2.5 text-center">Tiếp Tục Mua</Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-white/40 mb-6">
        <Link href="/" className="hover:text-white">Trang Chủ</Link>
        <span>/</span>
        <Link href={isRoblox ? '/products/roblox' : '/products/genshin'} className="hover:text-white">
          {isRoblox ? 'Roblox' : 'Genshin'}
        </Link>
        <span>/</span>
        <span className="text-white/70 truncate max-w-xs">{product.name}</span>
      </div>

      <div className="grid lg:grid-cols-5 gap-8">
        {/* Product image placeholder */}
        <div className="lg:col-span-2">
          <div className={`rounded-2xl h-72 flex items-center justify-center relative overflow-hidden ${isRoblox ? 'bg-gradient-roblox' : 'bg-gradient-genshin'}`}>
            <div className="scanlines absolute inset-0" />
            <div className="relative z-10 text-center">
              <div className="text-8xl mb-3">
                {product.category === 'account' ? '👤' : product.category === 'robux' ? '💎' : product.category === 'crystal' ? '🔮' : '⚙️'}
              </div>
              <span className={isRoblox ? 'badge-roblox' : 'badge-genshin'}>{product.game}</span>
            </div>
            {discountPct && (
              <div className="absolute top-3 right-3 bg-red-500 text-white font-display font-black text-lg px-3 py-1 rounded-lg">
                -{discountPct}%
              </div>
            )}
          </div>

          {/* Trust badges */}
          <div className="mt-4 space-y-2">
            {[
              { icon: <Zap size={14} />, text: 'Giao dịch tự động – nhận hàng ngay' },
              { icon: <Shield size={14} />, text: 'Bảo hành 24 giờ sau khi nhận' },
              { icon: <Package size={14} />, text: `Còn ${product.stock} trong kho` },
            ].map((b, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-white/60 glass-card px-3 py-2">
                <span className="text-neon-cyan">{b.icon}</span>
                {b.text}
              </div>
            ))}
          </div>
        </div>

        {/* Product info & purchase */}
        <div className="lg:col-span-3 space-y-5">
          {product.isFeatured && <span className="badge-hot">🔥 BÁN CHẠY</span>}
          <h1 className="font-display font-black text-2xl md:text-3xl text-white leading-tight">
            {product.name}
          </h1>

          {/* Price */}
          <div className="flex items-end gap-3">
            <div className="price-tag text-4xl">{formatCurrency(promoApplied ? Math.floor(product.price * 0.9) : product.price)}</div>
            {product.originalPrice && (
              <div className="text-white/40 text-lg line-through">{formatCurrency(product.originalPrice)}</div>
            )}
            {promoApplied && (
              <div className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded font-bold">-10% HE2026</div>
            )}
          </div>

          {/* Metadata */}
          {product.metadata && Object.keys(product.metadata).length > 0 && (
            <div className="glass-card p-4">
              <div className="text-xs font-bold text-white/50 uppercase tracking-wider mb-3">Chi Tiết Sản Phẩm</div>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(product.metadata).map(([key, value]) => (
                  <div key={key} className="flex items-start gap-2 text-sm">
                    <span className="text-white/40 capitalize">{key}:</span>
                    <span className="text-white font-semibold">
                      {Array.isArray(value) ? (value as string[]).join(', ') : String(value)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          {product.description && (
            <p className="text-white/60 text-sm leading-relaxed">{product.description}</p>
          )}

          {/* Quantity */}
          {product.category !== 'account' && (
            <div>
              <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block">Số Lượng</label>
              <div className="flex items-center gap-3">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-9 h-9 rounded-lg glass-card flex items-center justify-center text-white hover:text-neon-cyan text-lg font-bold">−</button>
                <span className="font-display font-bold text-xl text-white w-8 text-center">{quantity}</span>
                <button onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-9 h-9 rounded-lg glass-card flex items-center justify-center text-white hover:text-neon-cyan text-lg font-bold">+</button>
              </div>
            </div>
          )}

          {/* Promo code */}
          <div>
            <label className="text-xs font-bold text-white/60 uppercase tracking-wider mb-2 block flex items-center gap-1">
              <Tag size={12} /> Mã Giảm Giá
            </label>
            <div className="flex gap-2">
              <input value={promoCode} onChange={e => setPromoCode(e.target.value.toUpperCase())}
                placeholder="Nhập mã (VD: HE2026)"
                disabled={promoApplied}
                className="flex-1 bg-dark-600 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:outline-none focus:border-neon-cyan/50 font-mono disabled:opacity-50" />
              {!promoApplied && (
                <button onClick={applyPromo} className="btn-outline-neon py-2 px-4 text-sm">Áp Dụng</button>
              )}
              {promoApplied && (
                <div className="px-4 py-2 rounded bg-green-500/20 text-green-400 text-sm font-bold flex items-center gap-1">
                  <CheckCircle size={14} /> Đã áp dụng
                </div>
              )}
            </div>
          </div>

          {/* Total & buy */}
          <div className="border-t border-white/10 pt-4">
            <div className="flex items-center justify-between mb-4">
              <span className="text-white/60 font-semibold">Tổng Thanh Toán</span>
              <span className="price-tag text-2xl">{formatCurrency(total)}</span>
            </div>
            <button onClick={handleBuy} disabled={buying || product.stock === 0}
              className={`w-full py-4 rounded-xl flex items-center justify-center gap-2 font-display font-black text-base uppercase tracking-wider transition-all ${
                product.stock > 0
                  ? 'bg-gradient-neon text-dark-900 hover:shadow-neon'
                  : 'bg-dark-600 text-white/30 cursor-not-allowed'
              } disabled:opacity-60`}>
              {buying ? (
                <><Loader2 size={18} className="animate-spin" /> Đang xử lý...</>
              ) : product.stock > 0 ? (
                <><ShoppingCart size={18} /> Mua Ngay</>
              ) : (
                'Hết Hàng'
              )}
            </button>
            {!session && (
              <p className="text-center text-xs text-white/40 mt-2">
                Bạn cần <Link href="/login" className="text-neon-cyan">đăng nhập</Link> để mua hàng
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
