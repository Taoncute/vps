// src/components/FeaturedProducts.tsx
'use client'
import { ProductCard } from './ProductCard'

export function FeaturedProducts({ products }: { products: any[] }) {
  if (!products.length) return null
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
      {products.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  )
}
