// src/components/admin/AdminSidebar.tsx
'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { signOut } from 'next-auth/react'
import {
  LayoutDashboard, Package, Users, Receipt,
  Settings, LogOut, Sword, CreditCard, Database,
} from 'lucide-react'

const navItems = [
  { href: '/admin', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { href: '/admin/products', label: 'Sản Phẩm', icon: <Package size={18} /> },
  { href: '/admin/accounts', label: 'Kho Tài Khoản', icon: <Database size={18} /> },
  { href: '/admin/orders', label: 'Đơn Hàng', icon: <Receipt size={18} /> },
  { href: '/admin/recharges', label: 'Nạp Tiền', icon: <CreditCard size={18} /> },
  { href: '/admin/users', label: 'Người Dùng', icon: <Users size={18} /> },
  { href: '/admin/settings', label: 'Cài Đặt', icon: <Settings size={18} /> },
]

export function AdminSidebar({ user }: { user: any }) {
  const pathname = usePathname()

  return (
    <aside className="w-56 flex-shrink-0 bg-dark-800 border-r border-white/5 flex flex-col">
      {/* Logo */}
      <div className="p-4 border-b border-white/5">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-7 h-7 bg-gradient-neon rounded-lg flex items-center justify-center">
            <Sword size={14} className="text-dark-900" />
          </div>
          <span className="font-display font-black text-sm">
            <span className="text-neon-cyan">GAME</span><span className="text-white">SHOP</span>
          </span>
        </Link>
        <div className="mt-3 flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-neon-purple flex items-center justify-center text-xs font-bold text-white">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <div className="text-xs font-bold text-white truncate max-w-[100px]">{user?.name}</div>
            <div className="text-[10px] text-neon-purple font-display uppercase">Admin</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5">
        {navItems.map((item) => {
          const active = item.href === '/admin'
            ? pathname === '/admin'
            : pathname.startsWith(item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                active
                  ? 'bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/20'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className={active ? 'text-neon-cyan' : 'text-white/40'}>{item.icon}</span>
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* Logout */}
      <div className="p-3 border-t border-white/5">
        <button
          onClick={() => signOut({ callbackUrl: '/' })}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut size={16} /> Đăng Xuất
        </button>
      </div>
    </aside>
  )
}
