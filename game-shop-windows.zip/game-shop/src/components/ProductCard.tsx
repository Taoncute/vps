// src/components/ProductCard.tsx
'use client'
import Link from 'next/link'
import { formatCurrency } from '@/lib/utils'
import { ShoppingCart, Zap, Package } from 'lucide-react'

interface ProductCardProps {
  product: {
    id: string
    name: string
    description?: string | null
    price: number
    originalPrice?: number | null
    game: string
    category: string
    stock: number
    sold: number
    isFeatured: boolean
    metadata?: any
  }
}

export function ProductCard({ product }: ProductCardProps) {
  const isRoblox = product.game === 'ROBLOX'
  const isGenshin = product.game === 'GENSHIN'
  const discountPct = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : null

  const categoryIcon = {
    account: '👤',
    robux: '💎',
    crystal: '🔮',
    service: '⚙️',
  }[product.category] ?? '🎮'

  const categoryLabel = {
    account: 'Tài Khoản',
    robux: 'Robux',
    crystal: 'Genesis Crystals',
    service: 'Dịch Vụ',
  }[product.category] ?? product.category

  return (
    <Link href={`/products/${isRoblox ? 'roblox' : 'genshin'}/${product.id}`}>
      <div className="game-card group cursor-pointer h-full flex flex-col">
        {/* Card header / thumbnail */}
        <div
          className={`relative h-40 flex items-center justify-center overflow-hidden ${
            isRoblox ? 'bg-gradient-roblox' : 'bg-gradient-genshin'
          } opacity-80 group-hover:opacity-100 transition-opacity`}
        >
          {/* Scanlines effect */}
          <div className="scanlines absolute inset-0" />

          <div className="relative z-10 text-center">
            <div className="text-5xl mb-1">{categoryIcon}</div>
            <div className="font-display font-bold text-white/90 text-sm uppercase tracking-wider">
              {categoryLabel}
            </div>
          </div>

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {isRoblox && <span className="badge-roblox">ROBLOX</span>}
            {isGenshin && <span className="badge-genshin">GENSHIN</span>}
          </div>
          <div className="absolute top-2 right-2 flex flex-col gap-1 items-end">
            {product.isFeatured && <span className="badge-hot">HOT</span>}
            {discountPct && (
              <span className="bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded font-display">
                -{discountPct}%
              </span>
            )}
          </div>

          {/* Stock indicator */}
          {product.stock <= 5 && product.stock > 0 && (
            <div className="absolute bottom-2 right-2 text-xs bg-orange-500/80 text-white px-2 py-0.5 rounded font-bold">
              Còn {product.stock}
            </div>
          )}
          {product.stock === 0 && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <span className="font-display font-bold text-white/70 text-sm uppercase tracking-wider">
                Hết Hàng
              </span>
            </div>
          )}
        </div>

        {/* Card body */}
        <div className="p-4 flex flex-col flex-1">
          <h3 className="font-bold text-white text-sm leading-snug mb-1 line-clamp-2 group-hover:text-neon-cyan transition-colors">
            {product.name}
          </h3>
          {product.description && (
            <p className="text-xs text-white/50 line-clamp-2 mb-3 flex-1">{product.description}</p>
          )}

          {/* Meta info */}
          {product.metadata && (
            <div className="flex flex-wrap gap-1.5 mb-3">
              {product.metadata.level && (
                <span className="text-xs bg-dark-600 text-white/60 px-2 py-0.5 rounded font-mono">
                  Lv.{product.metadata.level}
                </span>
              )}
              {product.metadata.ar && (
                <span className="text-xs bg-dark-600 text-white/60 px-2 py-0.5 rounded font-mono">
                  AR{product.metadata.ar}
                </span>
              )}
              {product.metadata.server && (
                <span className="text-xs bg-dark-600 text-white/60 px-2 py-0.5 rounded">
                  {product.metadata.server}
                </span>
              )}
            </div>
          )}

          {/* Price & action */}
          <div className="flex items-center justify-between mt-auto pt-3 border-t border-white/5">
            <div>
              <div className="price-tag text-base">{formatCurrency(product.price)}</div>
              {product.originalPrice && (
                <div className="text-xs text-white/40 line-through">
                  {formatCurrency(product.originalPrice)}
                </div>
              )}
            </div>
            <div className="flex items-center gap-1 text-xs text-white/40">
              <Package size={11} />
              <span className="font-mono">{product.sold}</span>
            </div>
          </div>

          {/* Buy button */}
          <button
            className={`mt-3 w-full py-2 rounded text-xs font-display font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all
              ${product.stock > 0
                ? 'bg-gradient-neon text-dark-900 hover:shadow-neon'
                : 'bg-dark-600 text-white/30 cursor-not-allowed'
              }`}
            disabled={product.stock === 0}
          >
            {product.stock > 0 ? (
              <><ShoppingCart size={13} /> Mua Ngay</>
            ) : (
              <><Zap size={13} /> Hết Hàng</>
            )}
          </button>
        </div>
      </div>
    </Link>
  )
}
