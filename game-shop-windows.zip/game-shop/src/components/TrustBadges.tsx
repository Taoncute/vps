// src/components/TrustBadges.tsx
import { Shield, Zap, HeadphonesIcon, RefreshCw } from 'lucide-react'

export function TrustBadges() {
  const badges = [
    { icon: <Zap size={20} className="text-neon-cyan" />, label: 'Tự Động 24/7' },
    { icon: <Shield size={20} className="text-neon-purple" />, label: 'Cloudflare DDoS' },
    { icon: <HeadphonesIcon size={20} className="text-neon-gold" />, label: 'Hỗ Trợ Nhanh' },
    { icon: <RefreshCw size={20} className="text-neon-green" />, label: 'Hoàn Tiền 100%' },
  ]

  return (
    <div className="border-y border-white/5 bg-dark-800/50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-white/5">
          {badges.map((b) => (
            <div key={b.label} className="flex items-center justify-center gap-2 py-3 px-4">
              {b.icon}
              <span className="font-display font-semibold text-xs uppercase tracking-wider text-white/70">
                {b.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
