// src/components/HeroBanner.tsx
'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const slides = [
  {
    game: 'ROBLOX',
    title: 'BLOX FRUITS',
    subtitle: 'TÀI KHOẢN CAO CẤP',
    desc: 'Level 2450 Max · Tộc V4 · CDK Đầy Đủ · Giá Tốt Nhất',
    cta: 'Xem Ngay',
    href: '/products/roblox',
    accent: 'from-red-600 via-orange-500 to-yellow-500',
    badge: 'ROBLOX',
    emoji: '🎮',
  },
  {
    game: 'GENSHIN',
    title: 'GENSHIN IMPACT',
    subtitle: 'TÀI KHOẢN VIP',
    desc: 'AR55 · 5+ Nhân Vật 5★ · La Hoàn 36* · Server Asia',
    cta: 'Khám Phá',
    href: '/products/genshin',
    accent: 'from-violet-600 via-pink-500 to-yellow-400',
    badge: 'GENSHIN',
    emoji: '✨',
  },
  {
    game: 'PROMO',
    title: 'KHUYẾN MÃI',
    subtitle: 'MÃ HE2026',
    desc: 'Nhập mã HE2026 để nhận giảm giá 10% cho mọi đơn hàng',
    cta: 'Nạp Tiền Ngay',
    href: '/recharge',
    accent: 'from-cyan-500 via-blue-500 to-purple-600',
    badge: 'HOT',
    emoji: '🎉',
  },
]

export function HeroBanner() {
  const [current, setCurrent] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  const goTo = (idx: number) => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrent(idx)
    setTimeout(() => setIsAnimating(false), 500)
  }

  useEffect(() => {
    const timer = setInterval(() => goTo((current + 1) % slides.length), 5000)
    return () => clearInterval(timer)
  }, [current])

  const slide = slides[current]

  return (
    <section className="relative h-[480px] md:h-[560px] overflow-hidden grid-bg">
      {/* Background glow */}
      <div
        className={`absolute inset-0 bg-gradient-to-br ${slide.accent} opacity-10 transition-all duration-700`}
      />

      {/* Particle dots */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-neon-cyan/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
        <div
          key={current}
          className="max-w-2xl"
          style={{ animation: 'fade-up 0.5s ease-out' }}
        >
          {/* Badge */}
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold font-display uppercase tracking-widest mb-4 bg-gradient-to-r ${slide.accent}`}>
            <span className="text-white/90">{slide.emoji}</span>
            <span className="text-white">{slide.badge}</span>
          </div>

          {/* Title */}
          <h1 className="font-display font-black text-5xl md:text-7xl tracking-tight mb-2 leading-none">
            <span className={`bg-gradient-to-r ${slide.accent} bg-clip-text text-transparent`}>
              {slide.title}
            </span>
          </h1>
          <div className="font-display font-bold text-xl md:text-2xl text-white/80 uppercase tracking-widest mb-3">
            {slide.subtitle}
          </div>
          <p className="text-white/60 text-base md:text-lg mb-8 font-body">{slide.desc}</p>

          <div className="flex flex-wrap gap-3">
            <Link href={slide.href} className="btn-neon">
              {slide.cta}
            </Link>
            <Link href="/recharge" className="btn-outline-neon">
              Nạp Tiền
            </Link>
          </div>
        </div>

        {/* Big emoji decoration */}
        <div className="hidden lg:block absolute right-20 top-1/2 -translate-y-1/2 text-[200px] opacity-10 select-none animate-float">
          {slide.emoji}
        </div>
      </div>

      {/* Nav buttons */}
      <button
        onClick={() => goTo((current - 1 + slides.length) % slides.length)}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full glass-card flex items-center justify-center hover:border-neon-cyan/50 transition-colors"
      >
        <ChevronLeft size={20} className="text-white/70" />
      </button>
      <button
        onClick={() => goTo((current + 1) % slides.length)}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full glass-card flex items-center justify-center hover:border-neon-cyan/50 transition-colors"
      >
        <ChevronRight size={20} className="text-white/70" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              i === current ? 'w-8 bg-neon-cyan' : 'w-2 bg-white/30 hover:bg-white/60'
            }`}
          />
        ))}
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-dark-900 to-transparent" />
    </section>
  )
}
