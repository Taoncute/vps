// src/components/Navbar.tsx
'use client'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { useState } from 'react'
import { formatCurrency } from '@/lib/utils'
import { useBalance } from '@/hooks/useBalance'
import {
  Gamepad2, Zap, Menu, X, ChevronDown, LogOut, User, Shield, Wallet,
  Star, Sword,
} from 'lucide-react'

export function Navbar() {
  const { data: session } = useSession()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const balance = useBalance()

  const navLinks = [
    {
      label: 'Roblox',
      href: '/products/roblox',
      icon: <Gamepad2 size={14} />,
      sub: [
        { label: 'Tài Khoản', href: '/products/roblox?cat=account' },
        { label: 'Nạp Robux', href: '/products/roblox?cat=robux' },
        { label: 'Dịch Vụ', href: '/products/roblox?cat=service' },
      ],
    },
    {
      label: 'Genshin',
      href: '/products/genshin',
      icon: <Star size={14} />,
      sub: [
        { label: 'Tài Khoản', href: '/products/genshin?cat=account' },
        { label: 'Nạp Crystals', href: '/products/genshin?cat=crystal' },
        { label: 'Dịch Vụ', href: '/products/genshin?cat=service' },
      ],
    },
    { label: 'Nạp Tiền', href: '/recharge', icon: <Zap size={14} /> },
  ]

  return (
    <header className="sticky top-0 z-50">
      {/* Announcement bar */}
      <div className="bg-gradient-neon text-dark-900 text-center py-1.5 text-xs font-bold font-display tracking-wider">
        🎉 NHẬP MÃ <span className="bg-dark-900 text-neon-cyan px-1.5 py-0.5 rounded mx-1">HE2026</span> GIẢM NGAY 10% ĐƠN HÀNG ĐẦU TIÊN
      </div>

      <nav className="bg-dark-800/95 backdrop-blur-md border-b border-white/5">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="relative w-8 h-8">
                <div className="absolute inset-0 bg-gradient-neon rounded-lg opacity-80 group-hover:opacity-100 transition-opacity animate-glow-pulse" />
                <Sword size={16} className="absolute inset-0 m-auto text-dark-900" />
              </div>
              <div>
                <span className="font-display font-black text-lg tracking-wider">
                  <span className="text-neon-cyan">GAME</span>
                  <span className="text-white">SHOP</span>
                  <span className="text-neon-gold"> VN</span>
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) =>
                link.sub ? (
                  <div key={link.label} className="relative group">
                    <button className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white/80 hover:text-neon-cyan transition-colors rounded-lg hover:bg-white/5">
                      {link.icon}
                      {link.label}
                      <ChevronDown size={12} className="group-hover:rotate-180 transition-transform" />
                    </button>
                    <div className="absolute top-full left-0 mt-1 w-44 bg-dark-700 border border-white/10 rounded-xl overflow-hidden opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all duration-200 shadow-card">
                      {link.sub.map((s) => (
                        <Link
                          key={s.href}
                          href={s.href}
                          className="block px-4 py-2.5 text-sm text-white/70 hover:text-neon-cyan hover:bg-white/5 transition-colors font-medium"
                        >
                          {s.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                ) : (
                  <Link
                    key={link.href}
                    href={link.href}
                    className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white/80 hover:text-neon-cyan transition-colors rounded-lg hover:bg-white/5"
                  >
                    {link.icon}
                    {link.label}
                  </Link>
                )
              )}
            </div>

            {/* Right side */}
            <div className="flex items-center gap-3">
              {session ? (
                <div className="relative">
                  <button
                    onClick={() => setUserOpen(!userOpen)}
                    className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-dark-600 border border-white/10 hover:border-neon-cyan/30 transition-colors"
                  >
                    <div className="w-7 h-7 rounded-full bg-gradient-neon flex items-center justify-center">
                      <User size={14} className="text-dark-900" />
                    </div>
                    <div className="text-left hidden sm:block">
                      <div className="text-xs font-bold text-white leading-none">{session.user.name}</div>
                      <div className="text-xs text-neon-gold font-mono mt-0.5">
                        {formatCurrency(balance ?? 0)}
                      </div>
                    </div>
                    <ChevronDown size={12} className={`text-white/50 transition-transform ${userOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {userOpen && (
                    <div className="absolute right-0 top-full mt-2 w-52 bg-dark-700 border border-white/10 rounded-xl overflow-hidden shadow-card">
                      <div className="px-4 py-3 border-b border-white/5">
                        <div className="text-xs text-white/50">Số dư tài khoản</div>
                        <div className="text-base font-bold text-neon-gold font-display">
                          {formatCurrency(balance ?? 0)}
                        </div>
                      </div>
                      {session.user.role === 'ADMIN' && (
                        <Link href="/admin" className="flex items-center gap-2 px-4 py-2.5 text-sm text-neon-purple hover:bg-white/5">
                          <Shield size={14} /> Quản Trị
                        </Link>
                      )}
                      <Link href="/profile" className="flex items-center gap-2 px-4 py-2.5 text-sm text-white/70 hover:text-white hover:bg-white/5">
                        <User size={14} /> Tài Khoản
                      </Link>
                      <Link href="/recharge" className="flex items-center gap-2 px-4 py-2.5 text-sm text-white/70 hover:text-white hover:bg-white/5">
                        <Wallet size={14} /> Nạp Tiền
                      </Link>
                      <button
                        onClick={() => signOut()}
                        className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 border-t border-white/5"
                      >
                        <LogOut size={14} /> Đăng Xuất
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Link href="/login" className="btn-outline-neon text-xs py-1.5 px-4 hidden sm:flex">
                    Đăng Nhập
                  </Link>
                  <Link href="/register" className="btn-neon text-xs py-1.5 px-4">
                    Đăng Ký
                  </Link>
                </div>
              )}

              {/* Mobile toggle */}
              <button
                className="md:hidden p-2 rounded-lg hover:bg-white/5 text-white/80"
                onClick={() => setMobileOpen(!mobileOpen)}
              >
                {mobileOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-white/5 bg-dark-800 px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href ?? link.label}
                href={link.href ?? '#'}
                className="flex items-center gap-2 px-3 py-2.5 text-sm font-semibold text-white/80 hover:text-neon-cyan rounded-lg hover:bg-white/5"
                onClick={() => setMobileOpen(false)}
              >
                {link.icon} {link.label}
              </Link>
            ))}
            {!session && (
              <div className="flex gap-2 pt-2 border-t border-white/5 mt-2">
                <Link href="/login" className="flex-1 btn-outline-neon text-center text-xs py-2">Đăng Nhập</Link>
                <Link href="/register" className="flex-1 btn-neon text-center text-xs py-2">Đăng Ký</Link>
              </div>
            )}
          </div>
        )}
      </nav>
    </header>
  )
}
