// src/hooks/useBalance.ts
'use client'
import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'

export function useBalance() {
  const { data: session } = useSession()
  const [balance, setBalance] = useState<number | null>(null)

  useEffect(() => {
    if (!session) return
    fetch('/api/user/balance')
      .then((r) => r.json())
      .then((data) => setBalance(data.balance ?? 0))
      .catch(() => setBalance(0))
  }, [session])

  return balance
}
