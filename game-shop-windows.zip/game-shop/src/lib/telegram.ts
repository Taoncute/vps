// src/lib/telegram.ts
export async function sendTelegram(message: string): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN
  const chatId = process.env.TELEGRAM_ADMIN_ID
  if (!token || !chatId) return

  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'HTML',
      }),
    })
  } catch (err) {
    console.error('[Telegram]', err)
  }
}

export function buildOrderNotification(data: {
  orderId: string
  username: string
  product: string
  amount: number
  balance: number
}): string {
  return `
🛒 <b>ĐƠN HÀNG MỚI</b>
━━━━━━━━━━━━━━━━━
📋 Mã ĐH: <code>${data.orderId}</code>
👤 Người mua: <b>${data.username}</b>
🎮 Sản phẩm: ${data.product}
💰 Giá: <b>${new Intl.NumberFormat('vi-VN').format(data.amount)}đ</b>
💳 Số dư còn: ${new Intl.NumberFormat('vi-VN').format(data.balance)}đ
━━━━━━━━━━━━━━━━━
🕐 ${new Date().toLocaleString('vi-VN')}
`
}

export function buildRechargeNotification(data: {
  username: string
  method: string
  amount: number
  rawAmount: number
  userId: string
}): string {
  const methodLabel = data.method === 'CARD' ? '🃏 Thẻ cào' : '🏦 Chuyển khoản'
  return `
💵 <b>NẠP TIỀN THÀNH CÔNG</b>
━━━━━━━━━━━━━━━━━
👤 Người dùng: <b>${data.username}</b>
🆔 ID: <code>${data.userId}</code>
${methodLabel}
💸 Mệnh giá: ${new Intl.NumberFormat('vi-VN').format(data.rawAmount)}đ
✅ Nhận được: <b>${new Intl.NumberFormat('vi-VN').format(data.amount)}đ</b>
━━━━━━━━━━━━━━━━━
🕐 ${new Date().toLocaleString('vi-VN')}
`
}
