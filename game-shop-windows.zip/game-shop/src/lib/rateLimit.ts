// src/lib/rateLimit.ts
import { RateLimiterMemory } from 'rate-limiter-flexible'
import { NextRequest, NextResponse } from 'next/server'

const limiters: Record<string, RateLimiterMemory> = {}

function getLimiter(name: string, points: number, duration: number) {
  if (!limiters[name]) {
    limiters[name] = new RateLimiterMemory({ points, duration })
  }
  return limiters[name]
}

export async function rateLimit(
  req: NextRequest,
  name: string,
  { points = 10, duration = 60 } = {}
): Promise<NextResponse | null> {
  const ip =
    req.headers.get('cf-connecting-ip') ||
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-real-ip') ||
    '127.0.0.1'

  const limiter = getLimiter(name, points, duration)

  try {
    await limiter.consume(ip)
    return null // OK
  } catch {
    return NextResponse.json(
      { error: 'Quá nhiều yêu cầu. Vui lòng thử lại sau.' },
      { status: 429, headers: { 'Retry-After': String(duration) } }
    )
  }
}

// Presets
export const loginLimiter = (req: NextRequest) => rateLimit(req, 'login', { points: 5, duration: 60 })
export const rechargeLimiter = (req: NextRequest) => rateLimit(req, 'recharge', { points: 10, duration: 300 })
export const apiLimiter = (req: NextRequest) => rateLimit(req, 'api', { points: 60, duration: 60 })
