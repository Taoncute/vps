# 🚀 Hướng Dẫn Triển Khai & Bảo Mật GameShop VN

## 1. Cài Đặt Local (Termux / Linux)

```bash
# Clone và cài dependencies
cd game-shop
npm install

# Copy env
cp .env.example .env
# Điền đầy đủ các biến trong .env

# Setup database (cần PostgreSQL)
# Trên Termux:
pkg install postgresql
pg_ctl -D $PREFIX/var/lib/postgresql start
createdb gameshop

# Push schema và seed
npx prisma db push
npm run db:seed

# Chạy dev
npm run dev
```

---

## 2. Cấu Hình Biến Môi Trường (.env)

| Biến | Mô tả |
|------|-------|
| `DATABASE_URL` | PostgreSQL connection string |
| `NEXTAUTH_SECRET` | Chuỗi ngẫu nhiên >= 32 ký tự |
| `NEXTAUTH_URL` | URL website (https://yourdomain.com) |
| `CARD_API_PARTNER_ID` | Partner ID từ Thesieure.com |
| `CARD_API_PARTNER_KEY` | Partner Key từ Thesieure.com |
| `BANK_WEBHOOK_SECRET` | Secret từ SePay để verify webhook |
| `TELEGRAM_BOT_TOKEN` | Token bot Telegram |
| `TELEGRAM_ADMIN_ID` | Telegram Chat ID của admin |

---

## 3. Tích Hợp Nạp Thẻ (Thesieure.com)

1. Đăng ký tài khoản tại https://thesieure.com
2. Lấy `Partner ID` và `Partner Key` từ trang quản trị
3. Điền vào `.env`: `CARD_API_PARTNER_ID` và `CARD_API_PARTNER_KEY`
4. Webhook callback: Thesieure sẽ gọi API của bạn khi thẻ được xử lý xong
   - URL: `https://yourdomain.com/api/recharge/card/callback`

---

## 4. Tích Hợp Webhook Ngân Hàng (SePay)

1. Đăng ký tại https://sepay.vn
2. Kết nối tài khoản ngân hàng TPBank
3. Cấu hình Webhook URL: `https://yourdomain.com/api/recharge/bank/webhook`
4. Lấy `Webhook Secret` và điền vào `BANK_WEBHOOK_SECRET`

**Luồng hoạt động:**
```
Người dùng chuyển khoản → Ngân hàng → SePay → Webhook → Server → Cộng số dư
```

**Nội dung chuyển khoản phải đúng format:** `NAPTIEN XXXXXX`
(hệ thống tự tạo mã riêng cho từng user)

---

## 5. Cấu Hình Cloudflare Anti-DDoS

### Bước 1: Thêm domain vào Cloudflare
1. Vào https://cloudflare.com → Add Site
2. Đổi Nameserver về Cloudflare
3. Bật **Proxy (đám mây cam)** cho DNS record

### Bước 2: SSL/TLS
- Mode: **Full (Strict)**
- Bật **Always Use HTTPS**
- Bật **HSTS**

### Bước 3: Firewall Rules (WAF)
Tạo các quy tắc sau:

```
# Chặn các bot xấu phổ biến
(cf.client.bot) and not (cf.verified_bot_category in {"Search Engine Crawlers"})
→ Action: CHALLENGE

# Rate limit đăng nhập
(http.request.uri.path eq "/api/auth/callback/credentials")
→ Rate Limit: 5 requests / 60 seconds → BLOCK

# Rate limit nạp thẻ
(http.request.uri.path eq "/api/recharge/card")
→ Rate Limit: 10 requests / 300 seconds → BLOCK

# Chặn IP quốc tế nếu chỉ phục vụ VN
(ip.geoip.country ne "VN") and not (cf.verified_bot_category in {"Search Engine Crawlers"})
→ Action: JS_CHALLENGE (hoặc BLOCK nếu muốn)
```

### Bước 4: Under Attack Mode
Khi phát hiện DDoS:
1. Cloudflare Dashboard → Security → Settings
2. Security Level → **Under Attack**
3. Sau khi ổn định, đặt lại **High**

### Bước 5: Page Rules
```
https://yourdomain.com/admin/*
→ Security Level: High
→ Cache Level: Bypass
```

---

## 6. Deploy lên VPS / Vercel

### Vercel (khuyến nghị):
```bash
npm install -g vercel
vercel --prod
# Điền env variables trong Vercel Dashboard
```

### VPS (Ubuntu):
```bash
# Cài Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# PM2
npm install -g pm2
npm run build
pm2 start npm --name "gameshop" -- start
pm2 startup
pm2 save

# Nginx reverse proxy
sudo apt install nginx
```

**Nginx config (`/etc/nginx/sites-available/gameshop`):**
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 7. Tài Khoản Mặc Định

| Field | Giá trị |
|-------|---------|
| Email | admin@gameshop.vn |
| Password | Admin@123456 |
| Role | ADMIN |

**⚠️ Đổi mật khẩu ngay sau lần đăng nhập đầu tiên!**

---

## 8. Cấu Trúc Thư Mục

```
src/
├── app/
│   ├── (auth)/login/          # Trang đăng nhập
│   ├── (auth)/register/       # Trang đăng ký
│   ├── admin/                 # Admin dashboard
│   ├── products/roblox/       # Shop Roblox
│   ├── products/genshin/      # Shop Genshin
│   ├── recharge/              # Trang nạp tiền
│   ├── profile/               # Trang cá nhân
│   └── api/                   # API Routes
│       ├── auth/              # NextAuth + Register
│       ├── user/              # Balance, Profile, Bank info
│       ├── products/          # Purchase API
│       ├── recharge/          # Card + Bank webhook
│       └── admin/             # Admin CRUD APIs
├── components/                # UI Components
├── lib/                       # Prisma, Auth, Utils, Telegram
└── middleware.ts              # Route protection
prisma/
├── schema.prisma              # Database schema
└── seed.ts                    # Seed data
```

---

## 9. Checklist Trước Khi Go Live

- [ ] Đổi `NEXTAUTH_SECRET` thành chuỗi ngẫu nhiên mạnh
- [ ] Cấu hình đúng `DATABASE_URL` production
- [ ] Kết nối và test API Thesieure nạp thẻ
- [ ] Test webhook SePay với 1 giao dịch thật nhỏ
- [ ] Cấu hình Cloudflare + SSL
- [ ] Đổi mật khẩu admin
- [ ] Thêm sản phẩm thực tế vào Admin Panel
- [ ] Test toàn bộ luồng mua hàng từ đầu đến cuối
