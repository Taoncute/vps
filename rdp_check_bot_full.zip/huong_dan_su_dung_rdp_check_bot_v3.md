# Hướng dẫn sử dụng Telegram RDP Check Bot (Phiên bản 3 - Hỗ trợ định dạng phức tạp)

Chào bạn,

Đây là phiên bản nâng cấp của Telegram Bot, được thiết kế để xử lý các tệp danh sách RDP có định dạng phức tạp hơn, cụ thể là `IP:Port@User\Pass;`. Bot sẽ kiểm tra trạng thái hoạt động của cổng RDP và gửi báo cáo chi tiết về tài khoản Telegram của bạn.

## 1. Giới thiệu về Bot

Bot Telegram này giúp bạn tự động kiểm tra trạng thái hoạt động (Online/Offline) của các máy chủ RDP. Bot sẽ đọc danh sách từ tệp tin bạn cung cấp (ví dụ: `good.txt`), phân tích địa chỉ IP và cổng (nếu có), sau đó kiểm tra kết nối đến cổng RDP của từng máy và gửi báo cáo chi tiết đến tài khoản Telegram của bạn.

## 2. Chuẩn bị

Để bot có thể hoạt động, bạn cần có:

1.  **Telegram Bot Token**: Nếu bạn chưa có, hãy tìm kiếm `@BotFather` trên Telegram, gõ `/newbot` và làm theo hướng dẫn để tạo bot mới. BotFather sẽ cung cấp cho bạn một **HTTP API Token** (ví dụ: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`).
    *Lưu ý: Token của bạn đã được mình cập nhật vào mã nguồn là `8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q7803422532`.*

2.  **Telegram Chat ID của bạn**: Đây là ID duy nhất của cuộc trò chuyện giữa bạn và bot, nơi bot sẽ gửi thông báo. Để lấy Chat ID của bạn:
    *   Mở Telegram và tìm kiếm `@userinfobot`.
    *   Nhấn `/start` hoặc gửi bất kỳ tin nhắn nào cho bot này. Nó sẽ trả về Chat ID của bạn (một dãy số).

## 3. Cài đặt môi trường

Bot được viết bằng Python, vì vậy bạn cần cài đặt Python và thư viện `python-telegram-bot` trên máy chủ hoặc máy tính mà bạn muốn chạy bot.

1.  **Cài đặt Python 3**: Nếu bạn chưa có Python 3, bạn có thể tải xuống từ trang web chính thức: [python.org](https://www.python.org/downloads/).
2.  **Cài đặt thư viện `python-telegram-bot`**: Mở Terminal hoặc Command Prompt và chạy lệnh sau:
    ```bash
    pip install python-telegram-bot
    ```
    Hoặc nếu bạn có nhiều phiên bản Python:
    ```bash
    pip3 install python-telegram-bot
    ```

## 4. Mã nguồn Bot

Dưới đây là mã nguồn của bot. Bạn cần lưu mã này vào một tệp có tên `rdp_check_bot_v3.py`.

```python
import asyncio
import os
import re
from telegram import Bot
from telegram.constants import ParseMode

# --- CẤU HÌNH ---
# Thay thế bằng Token của bạn
TOKEN = '8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q7803422532'

# Thay thế bằng Chat ID của bạn (Bot sẽ gửi tin nhắn đến ID này)
# Bạn có thể lấy Chat ID bằng cách nhắn tin cho @userinfobot trên Telegram
CHAT_ID = 'YOUR_CHAT_ID'

# Tên file chứa danh sách RDP (mặc định là good.txt)
RDP_FILE = 'good.txt'

# Cổng RDP mặc định nếu không được chỉ định trong file
DEFAULT_RDP_PORT = 3389

# --- HÀM KIỂM TRA ---
async def check_rdp_port(host, port):
    """Kiểm tra xem cổng RDP có đang mở hay không."""
    try:
        # Sử dụng asyncio để kiểm tra kết nối TCP đến cổng RDP
        # Timeout 5 giây để tránh chờ đợi quá lâu
        conn = asyncio.open_connection(host, port)
        reader, writer = await asyncio.wait_for(conn, timeout=5.0)
        writer.close()
        await writer.wait_closed()
        return True, f"Online ✅"
    except asyncio.TimeoutError:
        return False, f"Offline ❌ (Timeout)"
    except Exception as e:
        return False, f"Offline ❌ (Lỗi: {str(e)})"

def parse_rdp_line(line):
    """
    Phân tích dòng RDP theo định dạng: IP:Port@User\\Pass;...
    Ví dụ: 122.176.135.197:3389@WIN-3NRLH5MC9LN\\administrator;
    """
    # Loại bỏ khoảng trắng và dấu chấm phẩy ở cuối
    line = line.strip().rstrip(';')
    
    # Tìm phần IP và Port trước dấu '@'
    if '@' in line:
        address_part = line.split('@')[0]
    else:
        address_part = line.split(';')[0] if ';' in line else line

    if ':' in address_part:
        try:
            host, port = address_part.split(':')
            port = int(port)
        except ValueError:
            host = address_part
            port = DEFAULT_RDP_PORT
    else:
        host = address_part
        port = DEFAULT_RDP_PORT
        
    return host, port

async def check_and_notify():
    """Đọc file, kiểm tra danh sách RDP và gửi thông báo về Telegram."""
    if not os.path.exists(RDP_FILE):
        print(f"Lỗi: Không tìm thấy file {RDP_FILE}. Vui lòng tạo file này trước.")
        return

    # Đọc danh sách RDP từ file
    with open(RDP_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        lines = [line.strip() for line in f if line.strip()]

    if not lines:
        print("Danh sách RDP trống.")
        return

    print(f"Đang kiểm tra {len(lines)} RDP từ file {RDP_FILE}...")
    
    results = []
    for line in lines:
        host, port = parse_rdp_line(line)
        is_online, status_text = await check_rdp_port(host, port)
        # Hiển thị dòng gốc thu gọn để dễ nhìn
        display_name = line.split('@')[0] if '@' in line else line[:30]
        results.append(f"🖥️ `{display_name}`: {status_text}")
    
    # Chia nhỏ tin nhắn nếu quá dài (Telegram giới hạn 4096 ký tự)
    header = f"📊 **Báo cáo trạng thái RDP ({len(lines)} máy):**\n\n"
    current_msg = header
    
    bot = Bot(token=TOKEN)
    
    for res in results:
        if len(current_msg) + len(res) + 2 > 4000:
            await bot.send_message(chat_id=CHAT_ID, text=current_msg, parse_mode=ParseMode.MARKDOWN)
            current_msg = header + res + "\n"
        else:
            current_msg += res + "\n"
            
    try:
        await bot.send_message(chat_id=CHAT_ID, text=current_msg, parse_mode=ParseMode.MARKDOWN)
        print("Đã gửi thông báo về Telegram thành công!")
    except Exception as e:
        print(f"Lỗi khi gửi tin nhắn Telegram: {e}")
        if 'Chat not found' in str(e) or 'Unauthorized' in str(e):
            print("\nLƯU Ý: Hãy đảm bảo bạn đã nhắn tin /start cho bot trước và CHAT_ID là chính xác.")

if __name__ == '__main__':
    if CHAT_ID == 'YOUR_CHAT_ID':
        print("Vui lòng cập nhật CHAT_ID trong file rdp_check_bot_v3.py!")
        print("Mẹo: Nhắn tin cho @userinfobot trên Telegram để lấy Chat ID của bạn.")
    else:
        asyncio.run(check_and_notify())
```

**Quan trọng**: Bạn cần thay thế chuỗi `YOUR_CHAT_ID` trong dòng `CHAT_ID = 'YOUR_CHAT_ID'` bằng Chat ID mà bạn đã nhận được từ `@userinfobot`.

## 5. Tạo tệp danh sách RDP (`good.txt`)

Bạn cần tạo một tệp văn bản có tên `good.txt` trong cùng thư mục với tệp `rdp_check_bot_v3.py`. Mỗi dòng trong tệp này sẽ chứa thông tin RDP theo định dạng bạn đã cung cấp:

`IP:Port@User\Pass;`

Bot sẽ tự động phân tích để lấy ra IP và Port để kiểm tra. Nếu Port không được chỉ định, bot sẽ mặc định sử dụng cổng `3389`.

**Ví dụ về nội dung tệp `good.txt`:**
```
122.176.135.197:3389@WIN-3NRLH5MC9LN\administrator;
117.206.117.82:3389@HALIMA\user;
43.230.64.234:3389@WIN-90Q6KIQ0CQS\test;
49.249.29.6:3389@USER\user;123
103.116.84.222:3389@DESKTOP-CBDMQPU\tally;123
```

## 6. Cách chạy Bot

Sau khi đã lưu mã nguồn, cập nhật `CHAT_ID` và tạo tệp `good.txt`, bạn có thể chạy bot bằng cách mở Terminal hoặc Command Prompt, điều hướng đến thư mục chứa tệp `rdp_check_bot_v3.py` và chạy lệnh sau:

```bash
python rdp_check_bot_v3.py
```
Hoặc:
```bash
python3 rdp_check_bot_v3.py
```

Bot sẽ thực hiện kiểm tra và gửi một tin nhắn báo cáo về Telegram của bạn.

## 7. Tự động hóa việc kiểm tra (Tùy chọn)

Để bot tự động kiểm tra định kỳ, bạn có thể sử dụng các công cụ lập lịch tác vụ của hệ điều hành:

*   **Trên Linux/macOS (Cron Job)**:
    Mở terminal và gõ `crontab -e`. Thêm dòng sau vào cuối tệp (ví dụ, để chạy mỗi 30 phút):
    ```cron
    */30 * * * * /usr/bin/python3 /duong/dan/den/rdp_check_bot_v3.py
    ```
    *Hãy thay `/usr/bin/python3` bằng đường dẫn đến trình thông dịch Python của bạn và `/duong/dan/den/rdp_check_bot_v3.py` bằng đường dẫn tuyệt đối đến tệp script của bạn.*

*   **Trên Windows (Task Scheduler)**:
    Bạn có thể thiết lập một tác vụ mới trong Task Scheduler để chạy tệp `rdp_check_bot_v3.py` theo lịch trình mong muốn.

Chúc bạn thành công! Nếu có bất kỳ câu hỏi nào, đừng ngần ngại hỏi nhé.
