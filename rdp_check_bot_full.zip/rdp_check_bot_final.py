import asyncio
import os
from telegram import Bot
from telegram.constants import ParseMode

# --- CẤU HÌNH ---
# Token và Chat ID của bạn đã được cập nhật trực tiếp
TOKEN = '8435659667:AAGK1zWRbkc1Y-XG6uaFz0nu1wW9k9WNH0Q'
CHAT_ID = '7803422532'

# Tên file chứa danh sách RDP (mặc định là good.txt)
RDP_FILE = 'good.txt'

# Cổng RDP mặc định nếu không được chỉ định trong file
DEFAULT_RDP_PORT = 3389

# --- HÀM KIỂM TRA ---
async def check_rdp_port(host, port):
    """Kiểm tra xem cổng RDP có đang mở hay không."""
    try:
        # Sử dụng asyncio để kiểm tra kết nối TCP đến cổng RDP
        # Timeout 5 giây để tránh chờ đợi quá lâu
        conn = asyncio.open_connection(host, port)
        reader, writer = await asyncio.wait_for(conn, timeout=5.0)
        writer.close()
        await writer.wait_closed()
        return True, f"Online ✅"
    except asyncio.TimeoutError:
        return False, f"Offline ❌ (Timeout)"
    except Exception as e:
        return False, f"Offline ❌ (Lỗi: {str(e)})"

def parse_rdp_line(line):
    """
    Phân tích dòng RDP theo định dạng: IP:Port@User\Pass;...
    Ví dụ: 122.176.135.197:3389@WIN-3NRLH5MC9LN\administrator;
    """
    # Loại bỏ khoảng trắng và dấu chấm phẩy ở cuối
    line = line.strip().rstrip(';')
    
    # Tìm phần IP và Port trước dấu '@'
    if '@' in line:
        address_part = line.split('@')[0]
    else:
        address_part = line.split(';')[0] if ';' in line else line

    if ':' in address_part:
        try:
            host, port = address_part.split(':')
            port = int(port)
        except ValueError:
            host = address_part
            port = DEFAULT_RDP_PORT
    else:
        host = address_part
        port = DEFAULT_RDP_PORT
        
    return host, port

async def check_and_notify():
    """Đọc file, kiểm tra danh sách RDP và gửi thông báo về Telegram."""
    if not os.path.exists(RDP_FILE):
        print(f"Lỗi: Không tìm thấy file {RDP_FILE}. Vui lòng tạo file này trước.")
        return

    # Đọc danh sách RDP từ file
    with open(RDP_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        lines = [line.strip() for line in f if line.strip()]

    if not lines:
        print("Danh sách RDP trống.")
        return

    print(f"Đang kiểm tra {len(lines)} RDP từ file {RDP_FILE}...")
    
    results = []
    for line in lines:
        host, port = parse_rdp_line(line)
        is_online, status_text = await check_rdp_port(host, port)
        # Hiển thị dòng gốc thu gọn để dễ nhìn
        display_name = line.split('@')[0] if '@' in line else line[:30]
        results.append(f"🖥️ `{display_name}`: {status_text}")
    
    # Chia nhỏ tin nhắn nếu quá dài (Telegram giới hạn 4096 ký tự)
    header = f"📊 **Báo cáo trạng thái RDP ({len(lines)} máy):**\n\n"
    current_msg = header
    
    bot = Bot(token=TOKEN)
    
    for res in results:
        if len(current_msg) + len(res) + 2 > 4000:
            try:
                await bot.send_message(chat_id=CHAT_ID, text=current_msg, parse_mode=ParseMode.MARKDOWN)
            except Exception as e:
                print(f"Lỗi khi gửi tin nhắn: {e}")
            current_msg = header + res + "\n"
        else:
            current_msg += res + "\n"
            
    try:
        await bot.send_message(chat_id=CHAT_ID, text=current_msg, parse_mode=ParseMode.MARKDOWN)
        print("Đã gửi thông báo về Telegram thành công!")
    except Exception as e:
        print(f"Lỗi khi gửi tin nhắn Telegram: {e}")
        print("\nLƯU Ý: Hãy đảm bảo bạn đã nhắn tin /start cho bot trước.")

if __name__ == '__main__':
    asyncio.run(check_and_notify())
